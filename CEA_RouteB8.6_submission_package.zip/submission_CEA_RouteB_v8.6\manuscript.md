# Frailty and allergic disease share genetic architecture, partly through overlapping item content

**Running title:** Frailty, allergy and item overlap

**Authors:** Hongjuan Fang^1,\*; Lijuan Bu^2; Lili Wang^2; Qiang Wang^2,\*

**Affiliations:** ^1 Department of Endocrinology, Aviation General Hospital, Beijing 100012, China; ^2 Chinese PLA Center for Disease Control and Prevention, Beijing 100071, China.

**Corresponding authors:** Hongjuan Fang (tthfhj@163.com; ORCID 0000-0001-8321-9902) and Qiang Wang (wang76qiang@163.com; ORCID 0000-0003-4392-0889).

**Keywords:** immune ageing; frailty index; item overlap; epigenetic clocks; allergic disease; IL-18.

**Word count:** 3,482 (main text); **abstract:** 272 words; **figures:** 5; **tables:** 3.

---

## Abstract

**Background** Frailty indices are widely used as biomarkers of ageing, but their genetic correlation with allergic disease may be partly definitional because the index includes allergic items.

**Methods** We examined the 49-item UK Biobank frailty index, four clocks and three allergic outcomes in European-ancestry data. We quantified item overlap, estimated MHC-free genetic correlations, tested three lines that could indicate a residual (adult-onset preference, a blood-count index built without allergy items, and endpoints not represented in the index), and examined IL-18 as a candidate interface.

**Results** The index includes asthma (item 28) and hay fever/eczema (item 33); 2/49 items (4.1%) are the outcomes, and 9/49 are pain items. Frailty was more strongly correlated with asthma (rg 0.47) and rhinitis (0.36) than the clocks; because of the item overlap, part is definitional. The MHC-free rg was 0.467, and the non-HLA instrument retained the association (OR 3.85). The frailty–asthma correlation replicated in European-ancestry TAGC (rg 0.38, P = 1.9 × 10⁻¹⁵). This replicates the association; it does not test the residual. Three lines were consistent with a residual but none was decisive: adult-onset asthma was more strongly coupled (0.49 vs 0.21); a blood-count index built without allergy items (though outcome-informed) was associated with allergic disease (OR 1.31, unweighted; equal-weight 1.31; leave-one-out 1.18–1.34); and the FI did not represent sepsis (0.38) or chronic rhinosinusitis (0.15), whereas asthma with nasal polyps (0.64) was a subtype. IL-18 was associated with atopic dermatitis (OR 1.19) but not asthma (0.93) or rhinitis (0.97).

**Conclusions** Part of the correlation is definitional; the residual is suggestive but not quantified. Ageing biomarker studies should audit item content, and a blood-count index built without allergy items provides a testable correlate.

**Key messages**

- The 49-item frailty index includes asthma and hay fever/eczema (2/49).
- Part of the frailty–allergy genetic correlation is therefore definitional.
- A blood-count index built without allergy items is associated with allergic disease.

---

## Background

Frailty indices are among the most widely used biomarkers of biological ageing. They are constructed as the proportion of accumulated health deficits and are validated against mortality, disability and hospitalisation [1–3]. Their appeal is that they require only routine clinical information. Their limitation matters as much: they are general measures of health deficit, not measures of any specific organ system. An index may therefore include the disease being studied.

This matters for genetic studies of allergic disease. Asthma, allergic rhinitis and atopic dermatitis affect more than a billion people [4,5], are increasingly recognised in older adults [6], and have been linked to inflammageing [7,8]. Studies that use a frailty index as an exposure may find a genetic correlation with allergy simply because the index contains allergic items. The UK Biobank 49-item frailty index, the basis of the most widely used frailty GWAS [2,9], includes asthma and hay fever/allergic rhinitis/eczema. The size of this overlap has not been quantified in a genetic framework.

We therefore asked three questions. First, whether part of the frailty–allergy genetic correlation is definitional, and whether a residual is detectable. Second, whether that residual is consistent across independent lines. Third, whether there is a correlate built without allergy items that can be tested in population data. We addressed the first question by auditing the 49 items, the second by three independent lines (adult-onset preference, a blood-count index built without allergy items, and endpoints not represented in the index), and the third in NHANES. We also examined IL-18 as a candidate interface.

We do not claim that ageing causes allergy, that the residual is established, or that the blood-count index is ready for clinical use. The contribution is a measurement caution and a falsifiable framework.

---

## Methods

### Design and claim levels

The study has four layers: item audit, genetic correlation, population correlate and candidate interface. Discovery used FinnGen R12 [10]; replication used the European-ancestry Trans-National Asthma Genetic Consortium (TAGC) meta-analysis for asthma (19,954 cases/107,715 controls; N = 127,669) [11] and the Budu-Aggrey meta-analysis for atopic dermatitis [12]. TAGC excludes UK Biobank; no TwinGene overlap is known. UK Biobank-based outcome cohorts [13–15] were internal consistency checks, not independent replication, because the frailty instrument is derived from UK Biobank. Sample overlap and independence are summarized in Supplementary Table 1.

Claims are labelled **established** (survives item audit, MHC removal and independent implementation), **supported** (consistent but not meeting the established criterion), **exploratory** (nominal/descriptive), or **not claimed**. The analysis plan for the discovery layers was archived on the Open Science Framework (https://osf.io/f4v79; qm2hy, f9d3w); later layers were added after the discovery analyses.

### The 49-item frailty index and its item audit

The frailty index was derived from UK Biobank (n = 164,610) and Swedish TwinGene (n = 10,616) [2,9]. In UK Biobank it is the sum of 49 self-reported deficits divided by the number of non-missing items (49 in complete cases), and was quantile-normalised before the GWAS [2,9]. We audited the item list against the outcomes using the original supplementary tables [2,9]. Items 28 (asthma) and 33 (hay fever, allergic rhinitis or eczema) are the outcomes themselves; 2/49 items (4.1%) are therefore definitional, with prevalences of 10.6% and 19.9% in the GWAS sample. Nine of 49 items (18.4%) are pain items. Item 17 (long-standing illness or disability) may also capture chronic allergic disease. The TwinGene 44-item version includes asthma (item 35) and a general allergy item (item 36), so the overlap is not UKB-specific. The full 49-item list is in Williams 2018.

We also computed an approximate phenotypic variance bound: assuming independence and published prevalences, an item with prevalence p contributes p(1−p)/49² to the FI variance. With FI SD = 0.075, each outcome item contributes ~0.7–1.5% of FI variance, or ~1.5–3% combined (Supplementary Note 8). This is a phenotypic bound, not a genetic decomposition.

### Ageing instruments and outcomes

We assembled four DNA-methylation clocks (GrimAge, 5 SNPs; Hannum, 56; IEAA, 133; and PhenoAge, 89) and the frailty index (66–71 SNPs, varying by outcome). Instruments were clumped at r² < 0.001 and had mean F > 10. The clocks were derived from ~34,400 European-ancestry participants [16–19]. Instrument properties and strength are summarized in Table 1 and Supplementary Table 2.

The outcomes were asthma (FinnGen ALLERG_ASTHMA), allergic rhinitis (ALLERG_RHINITIS) and atopic dermatitis (L12_ATOPIC). Childhood-onset and adult-onset asthma were defined as in Ferreira et al. [20].

### Genetic correlation and MR

MHC-free genetic correlations used canonical LDSC v1.0.1 [21] with HapMap3 weights and `--not-M-5-50`. The primary matrix covered all pairwise combinations of the five instruments and 5 × 3 disease correlations. We report cross-trait intercepts as a marker of sample overlap. Two-sample MR used inverse-variance weighting, with MR-Egger, weighted median, MR-PRESSO and MR-RAPS as sensitivity analyses [22–25]. Multivariable MR adjusted for BMI, smoking and education. A 13-SNP non-HLA instrument removed all canonical immune loci (±1 Mb). Because the frailty instrument is HLA-dominated, MR odds ratios are direction-only; the primary genetic metric is rg. Outcome genetic correlations are summarized in Table 2.

### NHANES

NHANES cycles D (2005–2006) and J (2017–2018) yielded 14,878 participants [26,27]. The allergic-outcome subset was cycle J (n = 7,021; 1,092 events); self-reported asthma (MCQ010) and hay fever (AGQ030) were combined into an allergic composite; the IgE subset was cycle D (n = 7,854); the age-gradient model used 9,360 participants. The blood-count index was constructed from eosinophil percentage, lymphocyte percentage, monocyte percentage, total white-cell count and C-reactive protein, standardised within cycle. It contains no allergy items. An equal-weight version used the same component directions but no outcome-derived weights; a leave-one-component-out analysis dropped each component in turn; a no-CRP version addressed the change from conventional to high-sensitivity CRP. Logistic models estimated per-SD odds ratios; survey weights were used for the age curve.

### HRS

In 45,234 Health and Retirement Study participants (723,744 person-waves) [28], a deficit-accumulation index was tracked against mortality and incident chronic disease. HRS does not measure allergy; it validates the clinical trajectory of the deficit index only.

### Candidate interface

cis-pQTL instruments were taken from the SCALLOP inflammatory-protein meta-analysis [29] and screened against the three outcomes (FDR < 0.1), requiring colocalisation PP.H4 > 0.8 [30,31]. IL18 and TNFSF14 were consistent across the SCALLOP, Luminex and HELIC platforms [29,32–35]. The same three cis instruments were used across platforms; independence is at the assay/cohort level, not the instrument level. The Tabula Sapiens 2.0 Lung atlas (65,847 cells; three donors aged 59–61) was used for descriptive localisation [36,37].

### Multiple testing and data

Discovery families were declared before analysis and controlled by Benjamini–Hochberg FDR. The families were: 15 instrument–outcome pairs, 12 frailty-versus-clock contrasts, 10 instrument–instrument correlations, and the cis-pQTL screen. Results not surviving family control are labelled nominal or exploratory. Data and code are archived at GitHub (https://github.com/wang76qiang/frailty-haematological-ageing-allergy-mr) and Zenodo (https://doi.org/10.5281/zenodo.22152039).

---

## Results

### The frailty index includes the outcomes

The UK Biobank 49-item FI includes asthma (item 28) and hay fever, allergic rhinitis or eczema (item 33; Figure 1c; Table 3; Supplementary Table 3). Two of 49 items (4.1%) are therefore the outcomes themselves; nine (18.4%) are pain items; item 17 (long-standing illness or disability) may also capture chronic allergic disease. In the GWAS sample, the prevalences were 10.6% and 19.9% (Figure 1f). The TwinGene 44-item version includes asthma (item 35) and a general allergy item (item 36), so the overlap is present in both cohorts. Part of any frailty–allergy correlation is therefore definitional.

The primary LDSC analysis was MHC-free: the frailty–asthma rg was 0.467 (SE 0.039); the MHC-inclusive rg was 0.492 (0.043), so the correlation is not driven by MHC-linked allergic signals. The 13-SNP non-HLA instrument also retained the association (OR 3.85). This argues against MHC-linked allergic items explaining the whole correlation, but it does not exclude non-HLA item overlap. Using the observed prevalences, an approximate variance bound attributes ~0.7% and ~1.2% of FI variance to the two items, or ~1.9% combined. This is a phenotypic bound, not a genetic decomposition; because genetic correlations are not proportional to phenotypic variance, the genetic contribution is unknown. Two of 49 items are sufficient to invalidate a causal interpretation even if their variance contribution is modest (Supplementary Note 8).

### The instruments are partially separable

The mean within-clock rg was 0.485 (range 0.286–0.658), versus 0.160 (0.056–0.294) between frailty and the clocks (Figure 1a,b,d,e; Table 1; Supplementary Table 4). Clock–clock cross-trait intercepts were 0.13–0.47, consistent with sample overlap among the clock GWAS; frailty–clock intercepts were approximately zero (Supplementary Table 5). The clocks therefore cluster, but some of that clustering reflects shared samples; frailty sits outside it.

### Part of the genetic correlation is definitional

The frailty instrument was genetically correlated with asthma (rg 0.467, SE 0.039; P = 3.8 × 10⁻³³), allergic rhinitis (0.361, 0.046; P = 1.2 × 10⁻¹⁴) and, more weakly, atopic dermatitis (0.246, 0.034; P = 4.7 × 10⁻¹⁴). The clocks were weaker and inconsistent: GrimAge was nominally correlated with asthma (0.165, 0.070; q = 0.034), IEAA with atopic dermatitis (0.161, 0.066; q = 0.029), and PhenoAge with atopic dermatitis (0.274, 0.102; q = 0.016); the remaining clock–outcome correlations were null (Figure 2a,b; Table 2; Supplementary Table 6).

Formal frailty-versus-clock contrasts were significant for asthma (Δrg 0.30–0.39; q ≤ 4.3 × 10⁻⁴) and rhinitis (Δrg 0.33–0.41; q ≤ 1.4 × 10⁻³), but not for atopic dermatitis: frailty (0.246) and PhenoAge (0.274) were indistinguishable, and the direction depended on the LDSC convention. We therefore limit the claim to asthma and rhinitis and report atopic dermatitis as unresolved (Figure 2d,e).

Because 2/49 items are the outcomes, part of the asthma/rhinitis correlation is definitional. The correlation survived multivariable MR for BMI, smoking and education (OR 2.68, P = 1.9 × 10⁻⁹) and removal of canonical immune loci (3.43 vs 3.44), and was retained by the non-HLA instrument for asthma (OR 3.85; Pan-UKB 2.38) and rhinitis (2.67; Figure 2f; Supplementary Table 7; Supplementary Note 9). Reverse MR effects were small (largest OR 1.024) but underpowered. Negative controls were null for type-1 diabetes, food allergy, ulcerative colitis and dementia.

Independent replication was available in the European-ancestry TAGC meta-analysis, which excludes UK Biobank (19,954 cases/107,715 controls; N = 127,669): the frailty–asthma genetic correlation was 0.378 (SE 0.048; P = 1.9 × 10⁻¹⁵; fixed-effects sensitivity 0.362, SE 0.046; Figure 2c), with a cross-trait intercept of −0.003 (SE 0.006). TAGC replicates the association but does not test the residual: the same two outcome items are present in the exposure. The attenuation relative to FinnGen (0.467) is consistent with winner's curse, phenotype definition and cohort heterogeneity. The UK Biobank-based cohorts were internally consistent but not independent: Han 2020 (UKB + TAGC) OR 2.25, Neale UKB 1.08, Pan-UKB 2.38 for the non-HLA instrument. Because Han overlaps both, we did not pool. For rhinitis, no non-UKB European cohort was available; the UKB estimate is internal consistency only.

### Three lines are consistent with a residual, but none is decisive

**Adult-onset preference.** The FI items ask about lifetime asthma, not age of onset. Coupling was stronger for adult-onset than childhood-onset asthma (rg 0.487 vs 0.209; Figure 3a). Childhood-onset GWAS had higher SNP heritability (0.067 vs 0.039) and mean χ², so this is not a simple power artefact. However, the two onset-stratified GWAS share a common control set, and adult-onset asthma carries more non-allergic FI deficits; the contrast is therefore suggestive, not specific.

**Endpoints not represented in the index.** In the phenome-wide scan, 12 of 17 endpoints were significant at FDR < 0.05, but 10 of the 12 are FI items, their subtypes, or the primary outcomes. The FI does not represent sepsis (rg 0.376) or chronic rhinosinusitis (0.154; Figure 3b,c); asthma with nasal polyps (0.637) is a subtype of the FI asthma item. Among allergic endpoints, only chronic rhinosinusitis is fully independent (0.154); sepsis is an infection endpoint rather than an allergic outcome. The approximate phenotypic variance bound for the two outcome items was also modest (Figure 3d).

**Blood-count index built without allergy items.** The index contains no allergy items but was associated with allergic disease in NHANES (OR 1.31 per SD, 95% CI 1.21–1.41; unweighted; Figure 4b) and with objective IgE (log-IgE β = 0.442; Figure 4d). The equal-weight version gave OR 1.31 (1.20–1.42; Supplementary Table 8), and leaving out each component in turn gave OR 1.18–1.34 (Figure 4b; Supplementary Table 9). The index is outcome-informed, however, so this is a different measurement layer, not an independent instrument.

None of these lines quantifies the residual. An item-excluded FI or a Fried phenotype is required.

### A blood-count index built without allergy items

The index rose with age by 0.079 SD per decade in the survey-weighted adult sample (0.064–0.094; Figure 4a); the unweighted estimate was 0.068. A no-CRP version gave a pooled age gradient of 0.068 SD/decade (0.055–0.082) and a period × age interaction of 0.041 (0.015–0.067; P = 0.002). We interpret this as a cross-sectional age gradient, not a longitudinal set-point.

The component analysis separated two signals (Figure 4b–d). The self-reported association was partly eosinophil-related: full index OR 1.31 per SD, eosinophil-free 1.18 (P = 1.8 × 10⁻⁴), eosinophil-only 1.24 (P = 1.7 × 10⁻⁹). IgE was eosinophil-carried: full β 0.442 (95% CI 0.364–0.519), eosinophil-only 0.301 (0.258–0.344), eosinophil-free −0.127 (−0.282 to 0.027).

The age gradient and the allergic association therefore do not depend on the outcome-informed weights or the CRP assay.

The age-by-index interaction was null (P = 0.394), but the study had 80% power only for a 40-year OR ratio of 1.134 or greater; we report the absence of a detectable interaction, not age invariance. In HRS, the deficit index rose from 0.187 to 0.261, predicted mortality (HR 1.61; time-varying 1.85) and showed rising within-person variance and lag-1 autocorrelation before death (Supplementary Information). HRS does not measure allergy; this layer validates the clinical trajectory, not the coupling.

### A candidate interface: IL-18 is atopic-dermatitis-anchored

Four cis-pQTL associations passed FDR < 0.1, all for atopic dermatitis. Colocalisation retained IL18 (PP.H4 = 0.968; Figure 5c) and TNFSF14 (0.976), and rejected TNF and TRAIL as linkage artefacts. IL18 was consistent across three assays (SCALLOP OR 1.19; Luminex 1.16; HELIC 1.22; pooled 1.19, 95% CI 1.15–1.23, I² = 0%; Figure 5a; Supplementary Table 10). The same instruments were used across platforms, so this is cross-assay consistency, not independent replication; instrument F was 172–331.

The same instruments were null for asthma (OR 0.93, 0.85–1.01; P = 0.09) and rhinitis (0.97, 0.90–1.06; P = 0.51), whereas the atopic dermatitis estimate was 1.19 (1.12–1.27; P = 7.0 × 10⁻⁹; Figure 5b). IL18 is therefore atopic-dermatitis-anchored, not shared with the asthma/rhinitis dimension.

In the lung atlas, IL18 localised to alveolar macrophages (75%), alveolar type-1 (71%), basophil (69%), type-2 (55%) and basal epithelium (59%), with IL33 confirming the basal-epithelial source (62%; Figure 5d). The atlas has three donors; this is descriptive. A safety scan showed concordant IL18 associations with psoriasis and fracture, and flagged infection/bone signals for TNFSF14. IL33 was protective across all three diseases, a counterpoint within the alarmin family.

### What would change the conclusion

If an item-excluded FI or a Fried phenotype attenuates the frailty–asthma/rhinitis correlation to near zero, the dimension claim should be replaced by a measurement caution: the correlation would be largely definitional. If the correlation persists, the residual component is confirmed. We pre-specify this test; the current data cannot resolve it.

---

## Discussion

We report a measurement caution with a testable residual. The 49-item frailty index includes asthma and hay fever/eczema; 2/49 items (4.1%) are the outcomes themselves. Part of the widely observed frailty–allergy genetic correlation is therefore definitional. The correlation was not explained by MHC-linked items. The primary rg was MHC-free (0.467), and the non-HLA instrument retained the association. The size of the non-definitional residual remains unknown. The variance bound is phenotypic, not genetic; it does not quantify the genetic contribution of the two items. TAGC [11] replicates the association but does not test the residual, because the same two outcome items are present in the exposure.

For ageing biomarker studies, frailty indices are general measures of deficit accumulation [1–3,9], not immune-specific instruments. Genetic studies that use them to study allergic disease should audit item content and, where possible, use an item-excluded index or a phenotype without allergic items. The same caution applies to other disease-specific items embedded in frailty indices (e.g., pneumonia, rheumatoid arthritis, psoriasis) [9]. A genetic correlation with a frailty index should not be interpreted as evidence that "biological ageing" causes the disease until item overlap is excluded.

The residual remains a hypothesis. Three lines are consistent with it: adult-onset asthma is more strongly coupled than childhood-onset, the blood-count index built without allergy items is associated with allergic disease, and sepsis and chronic rhinosinusitis are associated with frailty. None is decisive. Adult-onset asthma carries more non-allergic deficits; the blood-count index is outcome-informed; and asthma with nasal polyps is a subtype of the FI asthma item. The decisive test is an item-excluded FI or a Fried phenotype [38].

The evidence gap remains. In a rapid structured review, we found no study in the reviewed cohorts that used an item-excluded FI. The only within-survey comparison reported a larger estimate for the FI than for the Fried phenotype (OR 1.59 vs 1.25), compatible with construct overlap (Supplementary Note 11). A clinical cohort with an item-excluded FI or Fried phenotype is therefore the next step, not a prerequisite for the current measurement claim.

The blood-count index combines eosinophil, lymphocyte, monocyte, white-cell and CRP components. Its age gradient is haematologically general, with lymphocyte fraction falling and monocyte fraction rising. Its allergic association has two parts: self-report attenuates but remains significant after removing eosinophils (1.18), and eosinophil-only is 1.24; IgE is more strongly eosinophil-carried. It is a blood-count index with a type-2 component; it is not a type-2 set-point. It is not a clinical test. The per-SD effect is small, there is no incident data, and no decision rule.

IL-18 is anchored to atopic dermatitis. It is already known to be elevated in this disease [39], so the pQTL result confirms an established association. The same instruments were null for asthma and rhinitis, so IL-18 does not connect the main dimension to the main outcomes. It remains a candidate node for perturbation, not a validated drug target.

This study adds a verified item audit of a widely used frailty index and an ancestry-matched European TAGC replication of the frailty–asthma association. It also shows that a frailty index is not an immune-specific biomarker. It does not provide a clinical test or a quantified residual.

Clinically, the study does not provide a clinical test. Its value is aetiological and methodological: it identifies a measurement problem that can inflate frailty–allergy genetic correlations, and it provides a blood-count correlate built without allergy items that can be tested in primary-care cohorts with repeated blood counts. For clinicians and researchers who use frailty indices as immune-ageing biomarkers [6,40], the practical message is to audit item content before interpreting a frailty–allergy association; a frailty index is not an immune-specific instrument, and should not be used as an immune-ageing biomarker without item auditing.

### Limitations

(i) The frailty index includes asthma and hay fever/eczema items (2/49) and nine pain items; part of the correlation is definitional, the residual is not quantified, and an item-excluded index or Fried phenotype is needed.

(ii) The two onset-stratified GWAS share a common control set, and adult-onset asthma carries more non-allergic deficits; the adult-versus-childhood contrast is suggestive, not established.

(iii) The European-ancestry TAGC rg replicates the frailty–asthma association but does not test the residual, because the same two outcome items are present in the exposure. The independent replication is therefore asthma-specific; rhinitis and atopic dermatitis have no non-UKB European replication.

(iv) NHANES is cross-sectional and the main outcomes are self-reported; the age gradient cannot be separated fully from cohort and period effects. ORs are unweighted; the age curve is weighted, not design-based.

(v) The blood-count index is outcome-informed; the equal-weight, leave-one-out and no-CRP analyses are reassuring but do not replace an externally weighted index.

(vi) The pQTL evidence is anchored to atopic dermatitis, uses the same three cis instruments across platforms, and the lung atlas has three donors.

(vii) No incident-allergy cohort and no wet-lab experiment were available.

(viii) All genetic analyses are limited to European ancestry.

(ix) TAGC summary statistics were genomic-control-corrected (h² intercept 0.946), so the TAGC h² is attenuated; the fixed-effects sensitivity was consistent (rg 0.362). TAGC also used HapMap2-imputed summary statistics, which may attenuate the rg relative to FinnGen R12.

### Conclusions

Frailty and allergic disease share genetic architecture, but part of the correlation is definitional because the 49-item frailty index includes asthma and hay fever/eczema. The MHC-free rg was 0.467, the non-HLA instrument retained the association, and three lines are consistent with a residual, but the residual is not quantified. Ageing biomarker studies should audit item content; an item-excluded frailty index or a Fried phenotype is the decisive next test. A blood-count index built without allergy items is associated with allergic disease and can be tested in primary-care cohorts.

---

## Declarations

**Ethics approval and consent to participate** This study used publicly available, de-identified data only; no new human-subjects data were collected.

**Consent for publication** Not applicable.

**Availability of data and materials** Sources: FinnGen R12 (https://r12.finngen.fi); Pan-UK Biobank (https://pan.ukbb.broadinstitute.org); TAGC (GWAS Catalog GCST005212; European-ancestry meta-analysis, N = 127,669); NHANES (https://wwwn.cdc.gov/nchs/nhanes); HRS (https://hrs.isr.umich.edu); eQTLGen (https://www.eqtlgen.org); GTEx v8 (https://gtexportal.org); pQTL cohorts SCALLOP (GCST90012024), Ahola-Olli Luminex (GCST004441), HELIC (GCST90010141), AGES-Reykjavik (GCST90089017). Derived tables and code: GitHub (https://github.com/wang76qiang/frailty-haematological-ageing-allergy-mr) and Zenodo (concept DOI 10.5281/zenodo.22152039). Analysis plan: OSF (https://osf.io/f4v79).

**Competing interests** The authors declare no competing interests.

**Funding** Natural Science Foundation of Beijing Municipality (7232047 and 7242192) and Beijing Municipal Administration of Hospitals Incubating Program (PX2023019). The funders had no role in study design, analysis, interpretation or writing.

**Authors' contributions** H.F. and Q.W. conceptualised the study. H.F. designed the methodology and wrote the analysis software. H.F. and L.W. validated the results. L.B. performed the formal analysis. L.B. and L.W. conducted the investigation and data curation. H.F. wrote the original draft. L.W. and Q.W. reviewed and edited the manuscript. L.B. prepared the visualisations. Q.W. supervised the project. All authors read and approved the final manuscript.

**Acknowledgements** We thank the participants and investigators of FinnGen, NHANES, HRS, eQTLGen, DICE, OneK1K, Tabula Sapiens, GTEx, and the pQTL consortia.

**Use of AI-assisted technologies** AI-assisted tools were used for language editing, code assistance and figure preparation only; all analyses, data interpretation and conclusions were verified by the authors, who take full responsibility for the content.

---

## Figure legends

**Figure 1 | Measurement architecture.** a, MHC-free genetic correlation matrix among five ageing instruments. b, SNP heritability (h² ± SE). c, Composition of the 49-item frailty index: 2 outcome items, 9 pain items and 38 other items. d, Within-clock versus frailty–clock genetic correlations. e, Cross-trait intercepts for clock–clock and frailty–clock pairs. f, Prevalence of the two outcome items. Panels a and d show rg; panel e shows the cross-trait intercept; panel b shows h² ± SE.

**Figure 2 | Frailty–allergy coupling and replication.** a, Genetic correlation of the five instruments with asthma, allergic rhinitis and atopic dermatitis (MHC-free). b, Frailty versus clock estimates for asthma and rhinitis (rg, 95% CI). c, Frailty–asthma rg in FinnGen R12 and European-ancestry TAGC (random and fixed effects). d, Atopic dermatitis across all five instruments. e, Frailty versus the strongest clock for each outcome. f, Non-HLA instrument MR in FinnGen (asthma and rhinitis) and Pan-UKB (asthma) (OR, 95% CI).

**Figure 3 | Residual triangulation.** a, Adult-onset versus childhood-onset asthma. b, Phenome-wide scan of 17 endpoints, coloured by whether the endpoint is a primary outcome, an FI item/subtype, independent or other. c, Endpoints not represented in the frailty index; asthma with nasal polyps is a subtype of the FI asthma item, whereas sepsis and CRS are not represented. d, Approximate phenotypic variance contribution of the two outcome items. The lines are consistent with a residual but none is decisive.

**Figure 4 | Blood-count index built without allergy items.** a, Survey-weighted index by age decade in NHANES cycle J (weighted, not design-based). b, OR per SD for the primary, equal-weight, leave-one-out, eosinophil-free and eosinophil-only indices. c, Component ORs for self-reported allergic disease. d, Component β estimates for log-IgE. Error bars are 95% CI. Primary OR 1.31 (1.21–1.41); equal-weight 1.31 (1.20–1.42); eosinophil-free 1.18 (1.08–1.28); eosinophil-only 1.24 (1.16–1.33). The index is outcome-informed.

**Figure 5 | IL-18 is atopic-dermatitis-anchored.** a, cis-pQTL OR across SCALLOP, Luminex and HELIC assays, with pooled estimate. b, Outcome-specific IL-18 OR for atopic dermatitis, asthma and rhinitis. c, Colocalisation PP.H4 for IL18, TNFSF14, TNF and TRAIL. d, Lung cell-type expression of IL18 and IL33. The same three cis instruments were used across platforms; the atlas has three donors.

---

## Tables

**Table 1 | Ageing instruments and their properties.**

| Instrument | Construct | SNPs | h² (SE) | Mean χ² | λGC | Source cohort |
|---|---|---|---|---|---|---|
| Frailty index | Deficit accumulation (49 items) | 66–71 | 0.123 (0.006) | 1.40 | 1.33 | UKB 164,610 + TwinGene 10,616 |
| GrimAge | DNAm clock | 5 | 0.110 (0.019) | 1.08 | 1.07 | ~34,400 EUR |
| Hannum | DNAm clock | 56 | 0.137 (0.029) | 1.08 | 1.05 | ~34,400 EUR |
| IEAA | DNAm clock | 133 | 0.189 (0.027) | 1.10 | 1.06 | ~34,400 EUR |
| PhenoAge | DNAm clock | 89 | 0.115 (0.020) | 1.08 | 1.06 | ~34,400 EUR |

h² is SNP heritability from canonical LDSC. The 49-item FI includes asthma and hay fever/allergic rhinitis/eczema as items 28 and 33 (2/49); see Table 3 and Supplementary Table 3.

**Table 2 | Genetic correlation with the three allergic outcomes.**

| Instrument | Asthma rg (SE) | Rhinitis rg (SE) | Atopic dermatitis rg (SE) |
|---|---|---|---|
| Frailty | **0.467 (0.039)** | **0.361 (0.046)** | **0.246 (0.034)** |
| GrimAge | 0.165 (0.070) | −0.004 (0.085) | 0.091 (0.073) |
| Hannum | 0.113 (0.065) | 0.036 (0.084) | 0.116 (0.071) |
| IEAA | 0.083 (0.060) | −0.032 (0.073) | 0.161 (0.066) |
| PhenoAge | 0.082 (0.078) | −0.045 (0.093) | 0.274 (0.102) |

Bold indicates q < 0.05 within the 15-test family. The formal frailty-versus-clock contrasts were significant for asthma (q ≤ 4.3 × 10⁻⁴) and rhinitis (q ≤ 1.4 × 10⁻³) but not for atopic dermatitis. Because 2/49 FI items are the outcomes, part of the frailty correlation is definitional. Independent replication in the European-ancestry TAGC meta-analysis (which excludes UK Biobank; N = 127,669): frailty–asthma rg 0.378 (0.048; P = 1.9 × 10⁻¹⁵), intercept −0.003 (0.006); the same two outcome items are present in the exposure, so this replicates the association but does not test the residual.

**Table 3 | Flagged items in the 49-item frailty index.**

| Item # | Item | Category | Flag |
|---|---|---|---|
| 8 | Self-rated health | general | construct |
| 17 | Long-standing illness or disability | general | construct |
| 26 | Pneumonia | inflammatory | shared |
| 28 | Asthma | allergic outcome | OUTCOME |
| 29 | Rheumatoid arthritis | autoimmune | shared |
| 33 | Hay fever, allergic rhinitis or eczema | allergic outcome | OUTCOME |
| 34 | Psoriasis | autoimmune | shared |
| 37 | Chest pain | pain | construct |
| 38 | Head and/or neck pain | pain | construct |
| 39 | Back pain | pain | construct |
| 40 | Stomach/abdominal pain | pain | construct |
| 41 | Hip pain | pain | construct |
| 42 | Knee pain | pain | construct |
| 43 | Whole-body pain | pain | construct |
| 44 | Facial pain | pain | construct |
| 45 | Sciatica | pain | construct |

2/49 items (4.1%) are the outcomes themselves; 9/49 (18.4%) are pain items. The full 49-item list is in Williams et al. 2019; the complete audit is in Supplementary Table 3.

---

## References

1. Clegg A, Young J, Iliffe S, Rikkert MO, Rockwood K. Frailty in elderly people. Lancet. 2013;381:752–62.
2. Atkins JL, Jylhävä J, Pedersen NL, Magnusson PK, Lu Y, Wang Y, et al. A genome-wide association study of the frailty index highlights brain pathways in ageing. Aging Cell. 2021;20:e13459.
3. Jylhävä J, Pedersen NL, Hägg S. Biological age predictors. EBioMedicine. 2017;21:29–36.
4. Papi A, Brightling C, Pedersen SE, Reddel HK. Asthma. Lancet. 2018;391:783–800.
5. Vos T, Lim SS, Abbafati C, Abbas KM, Abbasi M, Abbasifard M, et al. Global burden of 369 diseases and injuries in 204 countries and territories, 1990–2019. Lancet. 2020;396:1204–22.
6. Baptist AP, Busse PJ. Asthma over the age of 65: all's well that ends well. J Allergy Clin Immunol Pract. 2018;6:764–73.
7. Franceschi C, Garagnani P, Parini P, Giuliani C, Santoro A. Inflammaging: a new immune-metabolic viewpoint for age-related diseases. Nat Rev Endocrinol. 2018;14:576–90.
8. Nikolich-Žugich J. The twilight of immunity: emerging concepts in aging of the immune system. Nat Immunol. 2018;19:10–9.
9. Williams DM, Jylhävä J, Pedersen NL, Hägg S. A frailty index for UK Biobank participants. J Gerontol A Biol Sci Med Sci. 2019;74:582–7.
10. Kurki MI, Karjalainen J, Palta P, Sipilä TP, Kristiansson K, Donner KM, et al. FinnGen provides genetic insights from a well-phenotyped isolated population. Nature. 2023;613:508–18.
11. Demenais F, Margaritte-Jeannin P, Barnes KC, Cookson WOC, Altmüller J, Ang W, et al. Multiancestry association study identifies new asthma risk loci that colocalize with immune-cell enhancer marks. Nat Genet. 2018;50:42–53.
12. Budu-Aggrey A, Kilanowski A, Sobczyk MK, Shringarpure SS, Mitchell R, Reis K, et al. European and multi-ancestry genome-wide association meta-analysis of atopic dermatitis highlights importance of systemic immune regulation. Nat Commun. 2023;14:6172.
13. Han Y, Jia Q, Jahani PS, Hurrell BP, Pan C, Huang P, et al. Genome-wide analysis highlights contribution of immune system pathways to the genetic architecture of asthma. Nat Commun. 2020;11:1776.
14. Neale Lab. UK Biobank GWAS results (round 2). Available from: http://www.nealelab.is/uk-biobank [accessed 25 Sep 2026].
15. Pan-UK Biobank. Available from: https://pan.ukbb.broadinstitute.org [accessed 25 Sep 2026].
16. McCartney DL, Min JL, Richmond RC, Lu AT, Sobczyk MK, Davies G, et al. Genome-wide association studies identify 137 genetic loci for DNA methylation biomarkers of aging. Genome Biol. 2021;22:194.
17. Hannum G, Guinney J, Zhao L, Zhang L, Hughes G, Sadda S, et al. Genome-wide methylation profiles reveal quantitative views of human aging rates. Mol Cell. 2013;49:359–67.
18. Levine ME, Lu AT, Quach A, Chen BH, Assimes TL, Bandinelli S, et al. An epigenetic biomarker of aging for lifespan and healthspan. Aging. 2018;10:573–91.
19. Lu AT, Quach A, Wilson JG, Reiner AP, Aviv A, Raj K, et al. DNA methylation GrimAge strongly predicts lifespan and healthspan. Aging. 2019;11:303–27.
20. Ferreira MAR, Mathur R, Vonk JM, Szwajda A, Brumpton B, Granell R, et al. Genetic architectures of childhood- and adult-onset asthma are partly distinct. Am J Hum Genet. 2019;104:665–84.
21. Bulik-Sullivan BK, Loh PR, Finucane HK, Ripke S, Yang J, Patterson N, et al. LD Score regression distinguishes confounding from polygenicity in genome-wide association studies. Nat Genet. 2015;47:291–5.
22. Bowden J, Davey Smith G, Burgess S. Mendelian randomization with invalid instruments: effect estimation and bias detection through Egger regression. Int J Epidemiol. 2015;44:512–25.
23. Bowden J, Davey Smith G, Haycock PC, Burgess S. Consistent estimation in Mendelian randomization with some invalid instruments using a weighted median estimator. Genet Epidemiol. 2016;40:304–14.
24. Verbanck M, Chen CY, Neale B, Do R. Detection of widespread horizontal pleiotropy in causal relationships inferred from Mendelian randomization between complex traits and diseases. Nat Genet. 2018;50:693–8.
25. Zhao Q, Wang J, Hemani G, Bowden J, Small DS. Statistical inference in two-sample summary-data Mendelian randomization using robust adjusted profile score. Ann Stat. 2020;48:1742–69.
26. Johnson CL, Paulose-Ram R, Ogden CL, Carroll MD, Kruszon-Moran D, Dohrmann SM, et al. National Health and Nutrition Examination Survey: analytic guidelines, 1999–2010. Vital Health Stat 2. 2013;161:1–24.
27. National Center for Health Statistics. National Health and Nutrition Examination Survey (NHANES), 2017–2018. Available from: https://wwwn.cdc.gov/nchs/nhanes [accessed 25 Sep 2026].
28. Sonnega A, Faul JD, Ofstedal MB, Langa KM, Phillips JW, Weir DR. Cohort profile: the Health and Retirement Study (HRS). Int J Epidemiol. 2014;43:576–85.
29. Zhao JH, Stacey D, Eriksson N, Macdonald-Dunlop E, Hedman ÅK, Kalnapenkis A, et al. Genetics of circulating inflammatory proteins identifies drivers of immune-mediated disease risk and therapeutic targets. Nat Immunol. 2023;24:1540–51.
30. Wallace C. A more accurate method for colocalisation analysis allowing for multiple causal variants. PLoS Genet. 2021;17:e1009440.
31. Zhu Z, Zhang F, Hu H, Bakshi A, Robinson MR, Powell JE, et al. Integration of summary data from GWAS and eQTL studies predicts complex trait gene targets. Nat Genet. 2016;48:481–7.
32. Folkersen L, Gustafsson S, Wang Q, Hansen DH, Hedman ÅK, Schork A, et al. Genomic and drug target evaluation of 90 cardiovascular proteins in 30,931 individuals. Nat Metab. 2020;2:1135–48.
33. Ahola-Olli AV, Würtz P, Havulinna AS, Aalto K, Pitkänen N, Lehtimäki T, et al. Genome-wide association study identifies 27 loci influencing concentrations of circulating cytokines and growth factors. Am J Hum Genet. 2017;100:40–50.
34. Gudjonsson A, Gudmundsdottir V, Axelsson GT, Gudmundsson EF, Jonsson BG, Launer LJ, et al. A genome-wide association study of serum proteins reveals shared loci with common diseases. Nat Commun. 2022;13:480.
35. Sun BB, Maranville JC, Peters JE, Stacey D, Staley JR, Blackshaw J, et al. Genomic atlas of the human plasma proteome. Nature. 2018;558:73–9.
36. The Tabula Sapiens Consortium. The Tabula Sapiens: a multiple-organ, single-cell transcriptomic atlas of humans. Science. 2022;376:eabl4896.
37. The Tabula Sapiens Consortium. Tabula Sapiens reveals transcription factor expression, senescence effects, and sex-specific features in cell types from 28 human organs and tissues. Preprint at https://doi.org/10.1101/2024.12.03.626516.

38. Fried LP, Tangen CM, Walston J, Newman AB, Hirsch C, Gottdiener J, et al. Frailty in older adults: evidence for a phenotype. J Gerontol A Biol Sci Med Sci. 2001;56:M146–56.
39. Bähler L, Schärli S, Luther F, Bertschi NL, Skabytska Y, Roediger B, Schlapbach C. IL-18 in atopic dermatitis—a multifaceted driver of skin inflammation. J Allergy Clin Immunol. 2025;156:1160–72.
40. Hoogendijk EO, Afilalo J, Ensrud KE, Kowal P, Onder G, Fried LP. Frailty: implications for clinical practice and public health. Lancet. 2019;394:1365–75.
