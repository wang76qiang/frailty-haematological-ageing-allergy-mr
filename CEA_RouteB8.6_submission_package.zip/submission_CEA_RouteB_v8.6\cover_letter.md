# Cover letter: Clinical & Experimental Allergy (Route B)

**Manuscript type:** Original Article
**Title:** Frailty and allergic disease share genetic architecture, partly through overlapping item content
**Date:** 21 October 2026

Dear Editors,

We submit a study of whether part of the genetic correlation between frailty and allergic disease is definitional. Frailty indices are widely used as biomarkers of ageing, but the 49-item UK Biobank index includes asthma and hay fever/allergic rhinitis/eczema as two of its 49 items. Genetic studies that use the index as an exposure may therefore report a correlation that is partly built into the instrument.

We quantified the overlap: 2/49 items (4.1%) are the outcomes themselves, and 9/49 are pain items. Frailty was more strongly genetically correlated with asthma (rg 0.47) and rhinitis (0.36) than four epigenetic clocks, but part of this correlation is definitional. The MHC-free rg was 0.467, the non-HLA instrument retained the association, and the frailty–asthma correlation replicated in European-ancestry TAGC (rg 0.38, P = 1.9 × 10⁻¹⁵). The replication supports the association; it does not test the residual. The same item overlap is present in the exposure. Three lines were consistent with a residual but none was decisive: adult-onset asthma was more strongly coupled than childhood-onset (0.49 vs 0.21); a blood-count index built without allergy items (though outcome-informed) was associated with allergic disease (OR 1.31; equal-weight 1.31; leave-one-out 1.18–1.34); and the FI did not represent sepsis (0.38) or chronic rhinosinusitis (0.15), whereas asthma with nasal polyps (0.64) was a subtype. IL-18 was associated with atopic dermatitis (1.19) but not asthma (0.93) or rhinitis (0.97).

This is relevant to your readers because it is a measurement caution with a testable consequence: ageing biomarker studies should audit item content, and a blood-count index built without allergy items provides a correlate that can be tested in primary-care cohorts. The residual is not quantified; we pre-specify the test (an item-excluded frailty index or a Fried phenotype) that would confirm or refute it. To address the absence of a clinical cohort, we include a rapid structured review (Supplementary Note 11): in the studies reviewed, no FI–allergy cohort used an item-excluded FI, and the only within-survey comparison reported a larger FI than phenotype estimate, compatible with construct overlap. A clinical cohort with an item-excluded FI is therefore the next step, not a prerequisite for the current measurement claim.

The manuscript presents five integrated figures and three tables. It is not under consideration elsewhere. All data are public or license-controlled; code and derived tables are archived at GitHub and Zenodo. All authors have approved the submission and declare no competing interests.

Yours sincerely,

Hongjuan Fang, MD, and Qiang Wang
(on behalf of all authors)



