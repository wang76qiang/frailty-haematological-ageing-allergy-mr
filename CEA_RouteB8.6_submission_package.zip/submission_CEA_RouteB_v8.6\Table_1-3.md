# Tables

**Table 1 | Ageing instruments and their properties.**

| Instrument | Construct | SNPs | h² (SE) | Mean χ² | λGC | Source cohort |
|---|---|---|---|---|---|---|
| Frailty index | Deficit accumulation (49 items) | 66–71 | 0.123 (0.006) | 1.40 | 1.33 | UKB 164,610 + TwinGene 10,616 |
| GrimAge | DNAm clock | 5 | 0.110 (0.019) | 1.08 | 1.07 | ~34,400 EUR |
| Hannum | DNAm clock | 56 | 0.137 (0.029) | 1.08 | 1.05 | ~34,400 EUR |
| IEAA | DNAm clock | 133 | 0.189 (0.027) | 1.10 | 1.06 | ~34,400 EUR |
| PhenoAge | DNAm clock | 89 | 0.115 (0.020) | 1.08 | 1.06 | ~34,400 EUR |

h² is SNP heritability from canonical LDSC. The 49-item FI includes asthma and hay fever/allergic rhinitis/eczema as items 28 and 33 (2/49); see Table 3 and Supplementary Table 3.

**Table 2 | Genetic correlation with the three allergic outcomes.**

| Instrument | Asthma rg (SE) | Rhinitis rg (SE) | Atopic dermatitis rg (SE) |
|---|---|---|---|
| Frailty | **0.467 (0.039)** | **0.361 (0.046)** | **0.246 (0.034)** |
| GrimAge | 0.165 (0.070) | −0.004 (0.085) | 0.091 (0.073) |
| Hannum | 0.113 (0.065) | 0.036 (0.084) | 0.116 (0.071) |
| IEAA | 0.083 (0.060) | −0.032 (0.073) | 0.161 (0.066) |
| PhenoAge | 0.082 (0.078) | −0.045 (0.093) | 0.274 (0.102) |

Bold indicates q < 0.05 within the 15-test family. The formal frailty-versus-clock contrasts were significant for asthma (q ≤ 4.3 × 10⁻⁴) and rhinitis (q ≤ 1.4 × 10⁻³) but not for atopic dermatitis. Because 2/49 FI items are the outcomes, part of the frailty correlation is definitional. Independent replication in the European-ancestry TAGC meta-analysis (which excludes UK Biobank; N = 127,669): frailty–asthma rg 0.378 (0.048; P = 1.9 × 10⁻¹⁵), intercept −0.003 (0.006); the same two outcome items are present in the exposure, so this replicates the association but does not test the residual.

**Table 3 | Flagged items in the 49-item frailty index.**

| Item # | Item | Category | Flag |
|---|---|---|---|
| 8 | Self-rated health | general | construct |
| 17 | Long-standing illness or disability | general | construct |
| 26 | Pneumonia | inflammatory | shared |
| 28 | Asthma | allergic outcome | OUTCOME |
| 29 | Rheumatoid arthritis | autoimmune | shared |
| 33 | Hay fever, allergic rhinitis or eczema | allergic outcome | OUTCOME |
| 34 | Psoriasis | autoimmune | shared |
| 37 | Chest pain | pain | construct |
| 38 | Head and/or neck pain | pain | construct |
| 39 | Back pain | pain | construct |
| 40 | Stomach/abdominal pain | pain | construct |
| 41 | Hip pain | pain | construct |
| 42 | Knee pain | pain | construct |
| 43 | Whole-body pain | pain | construct |
| 44 | Facial pain | pain | construct |
| 45 | Sciatica | pain | construct |

2/49 items (4.1%) are the outcomes themselves; 9/49 (18.4%) are pain items. The full 49-item list is in Williams et al. 2019; the complete audit is in Supplementary Table 3.
