# Supplementary Information

**Manuscript:** Frailty and allergic disease share genetic architecture, partly through overlapping item content

---

## Supplementary Table 1 | Sample-overlap audit

| Cohort | Role | Ancestry | Overlap with frailty GWAS | Overlap with UK Biobank | Independent | Use in paper |
|---|---|---|---|---|---|---|
| FinnGen R12 | Discovery | Finnish (EUR) | None | None | Yes | Primary discovery |
| TAGC (Demenais 2018) | Replication (asthma) | European-ancestry (N = 127,669) | None | None | Yes | Independent LDSC rg |
| Han 2020 | Replication (asthma) | EUR | UKB | Yes (UKB + TAGC) | No | Internal consistency only |
| Neale UKB | Replication (asthma/rhinitis) | EUR | UKB | Yes | No | Internal consistency only |
| Pan-UK Biobank | Replication | EUR | UKB | Yes | No | Internal consistency only |
| Budu-Aggrey 2023 (AD) | Replication (AD) | Multi-ancestry | UKB (likely partial) | Partial | Partly | Supportive; AD claims limited |
| Biobank Japan | Cross-ancestry | East Asian | None | None | Yes | Directional cross-ancestry support |

## Supplementary Table 2 | Instrument strength

| Instrument | SNPs | h² (SE) | Mean χ² | λGC | Source cohort |
|---|---|---|---|---|---|
| Frailty index | 66–71 | 0.123 (0.006) | 1.40 | 1.33 | UKB 164,610 + TwinGene 10,616 |
| GrimAge | 5 | 0.110 (0.019) | 1.08 | 1.07 | ~34,400 EUR |
| Hannum | 56 | 0.137 (0.029) | 1.08 | 1.05 | ~34,400 EUR |
| IEAA | 133 | 0.189 (0.027) | 1.10 | 1.06 | ~34,400 EUR |
| PhenoAge | 89 | 0.115 (0.020) | 1.08 | 1.06 | ~34,400 EUR |

## Supplementary Table 3 | Selected frailty-index items relevant to allergic and inflammatory disease

| Item # | Item | Category | Flag | Note |
|---|---|---|---|---|
| 8 | Self-rated health | general | construct | general health |
| 17 | Long-standing illness or disability | general | construct | may capture chronic allergic disease |
| 26 | Pneumonia | inflammatory | shared | inflammatory; not an allergic outcome |
| 28 | Asthma | allergic outcome | OUTCOME | DEFINITIONAL OVERLAP: outcome is an FI item |
| 29 | Rheumatoid arthritis | autoimmune | shared | autoimmune; shared inflammation |
| 33 | Hay fever, allergic rhinitis or eczema | allergic outcome | OUTCOME | DEFINITIONAL OVERLAP: outcome is an FI item |
| 34 | Psoriasis | autoimmune | shared | autoimmune; shared inflammation |
| 37 | Chest pain | pain | construct | pain |
| 38 | Head and/or neck pain | pain | construct | pain |
| 39 | Back pain | pain | construct | pain |
| 40 | Stomach/abdominal pain | pain | construct | pain |
| 41 | Hip pain | pain | construct | pain |
| 42 | Knee pain | pain | construct | pain |
| 43 | Whole-body pain | pain | construct | pain (Atkins 2021 reports 9/49 pain items) |
| 44 | Facial pain | pain | construct | pain |
| 45 | Sciatica | pain | construct | pain |

The UK Biobank 49-item FI (Williams 2018; item list as reported by Ward et al. 2021) includes asthma and hay fever/allergic rhinitis/eczema as items 28 and 33. Two of 49 items (4.1%) are therefore the outcomes themselves; nine of 49 (18.4%) are pain items. This is a definitional-overlap risk, reported in the main text and Limitations.

## Supplementary Table 4 | Genetic correlation among the five ageing instruments

| Pair | rg | SE |
|---|---|---|
| Frailty–GrimAge | 0.294 | 0.056 |
| Frailty–Hannum | 0.056 | 0.052 |
| Frailty–IEAA | 0.064 | 0.048 |
| Frailty–PhenoAge | 0.225 | 0.055 |
| GrimAge–Hannum | 0.314 | 0.090 |
| GrimAge–IEAA | 0.286 | 0.095 |
| GrimAge–PhenoAge | 0.658 | 0.100 |
| Hannum–IEAA | 0.594 | 0.077 |
| Hannum–PhenoAge | 0.480 | 0.094 |
| IEAA–PhenoAge | 0.575 | 0.076 |

Mean within-clock rg = 0.485 (range 0.286–0.658); mean frailty–clock rg = 0.160 (range 0.056–0.294). Clock–clock estimates share samples (cross-trait intercepts 0.13–0.47); frailty–clock estimates do not (intercepts approximately 0).

## Supplementary Table 5 | Cross-trait intercepts for the instrument–instrument matrix

| Pair | Cross-trait intercept | SE |
|---|---|---|
| Frailty-GrimAge | 0.0010 | 0.0048 |
| Frailty-Hannum | 0.0023 | 0.0045 |
| Frailty-IEAA | -0.0015 | 0.0051 |
| Frailty-PhenoAge | -0.0026 | 0.0054 |
| GrimAge-Hannum | 0.4058 | 0.0050 |
| GrimAge-IEAA | 0.1298 | 0.0048 |
| GrimAge-PhenoAge | 0.3800 | 0.0048 |
| Hannum-IEAA | 0.3667 | 0.0054 |
| Hannum-PhenoAge | 0.4719 | 0.0052 |
| IEAA-PhenoAge | 0.3850 | 0.0054 |

Clock–clock intercepts (0.13–0.47) indicate sample overlap; frailty–clock intercepts are approximately zero. This qualifies the clock cluster in Figure 1a.

## Supplementary Table 6 | Genetic correlation with the three allergic outcomes

| Instrument | Asthma rg (SE) | Rhinitis rg (SE) | Atopic dermatitis rg (SE) |
|---|---|---|---|
| Frailty | 0.467 (0.039) | 0.361 (0.046) | 0.246 (0.034) |
| GrimAge | 0.165 (0.070) | −0.004 (0.085) | 0.091 (0.073) |
| Hannum | 0.113 (0.065) | 0.036 (0.084) | 0.116 (0.071) |
| IEAA | 0.083 (0.060) | −0.032 (0.073) | 0.161 (0.066) |
| PhenoAge | 0.082 (0.078) | −0.045 (0.093) | 0.274 (0.102) |

An MHC-inclusive sensitivity gave frailty–asthma rg 0.492 (SE 0.043); the primary MHC-free estimate is 0.467 (0.039). The difference is small, so MHC-linked allergic signals do not explain the correlation.

## Supplementary Table 7 | Frailty-instrument MR sensitivity

| Outcome | IVW OR | MR-Egger OR (p) | Weighted median OR (p) | MR-PRESSO OR (p) | Egger intercept p |
|---|---|---|---|---|---|
| Asthma | 3.44 | 3.43 (<0.001) | 4.19 (2.1 × 10⁻⁷) | 3.38 (<0.001) | 0.80 |
| Allergic rhinitis | 1.69 | 1.70 (5.1 × 10⁻⁹) | 1.88 (8.5 × 10⁻⁸) | 1.75 (1.2 × 10⁻¹³) | 0.30 |
| Atopic dermatitis | 1.46 | 1.44 (9.0 × 10⁻⁴) | 1.39 (0.036) | 1.95* | 0.22 |

*The MR-PRESSO estimate for atopic dermatitis is outlier-corrected and unstable; it is reported for completeness, not as the primary estimate. MR odds ratios are direction-only because the frailty instrument is HLA-dominated and the per-SD effect is not clinically interpretable. Source: ST01/ST05.

## Supplementary Table 8 | Equal-weight blood-count index sensitivity

| Index | n | Age slope (SD/decade) | OR per SD (95% CI) | Correlation with primary index |
|---|---|---|---|---|
| Primary (outcome-informed) | 4,903 | 0.068 (unweighted; analysis n = 4,823) | 1.31 (1.21–1.41) | 1.00 |
| Equal-weight | 4,823 | 0.106 | 1.31 (1.20–1.42) | 0.69 |

The unweighted age slope was 0.068 SD/decade in the analysis sample (n = 4,823; index SD 0.576); the survey-weighted slope was 0.079 (0.064–0.094). ORs are unweighted; the age curve is weighted but not design-based. The primary index is the deposited `I` (weighted sum of standardised components; approximate weights recovered by regression: eosinophil +0.41, lymphocyte −0.39, monocyte −0.09, WBC +0.04, log CRP +0.08; R² = 0.987). The equal-weight index used the same component directions but no outcome-derived weights; it is already standardised. Component-index estimates (unweighted, same covariates): full 1.31 (1.21–1.41), eosinophil-free 1.18 (1.08–1.28), eosinophil-only 1.24 (1.16–1.33); log-IgE β 0.442 (0.364–0.519), −0.127 (−0.282 to 0.027), 0.301 (0.258–0.344).

## Supplementary Table 9 | Leave-one-component-out blood-count index

| Dropped component | OR per SD (95% CI) | Age slope (SD/decade) |
|---|---|---|
| none (full equal-weight) | 1.31 (1.20–1.42) | 0.106 |
| eosinophil | 1.18 (1.08–1.28) | 0.096 |
| lymphocyte | 1.25 (1.14–1.36) | 0.084 |
| monocyte | 1.28 (1.17–1.40) | 0.067 |
| wbc | 1.34 (1.24–1.45) | 0.118 |
| crp | 1.32 (1.21–1.44) | 0.113 |

The equal-weight index was recomputed after dropping each component in turn; all versions remained associated with allergic disease and rose with age. No single component drives the signal.

## Supplementary Table 10 | Outcome-specific IL18 cis-pQTL estimates

| Outcome | OR (95% CI) | P |
|---|---|---|
| Atopic dermatitis | 1.19 (1.12–1.26) | 7.0 × 10⁻⁹ |
| Asthma | 0.93 (0.85–1.01) | 0.09 |
| Allergic rhinitis | 0.97 (0.90–1.06) | 0.51 |

The same three cis instruments (rs5744249, rs10891343, rs7106524) were used across outcomes. The atopic dermatitis estimate is the cross-assay pooled estimate; asthma and rhinitis are IVW estimates in FinnGen R12.

## Supplementary Note 1 | No-CRP sensitivity

CRP was measured with a conventional assay in cycle D and a high-sensitivity assay in cycle J; the index includes CRP. A no-CRP version gave a pooled age gradient of 0.068 SD per decade (95% CI 0.055–0.082) and a period × age interaction of 0.041 (0.015–0.067; P = 0.002). The CRP component itself ran in the opposite direction (−0.052; P = 4.4 × 10⁻⁴), and the interaction was carried by blood-count components. The age gradient is therefore not an assay artefact.

## Supplementary Note 2 | Exploratory single-cell analysis

The Tabula Sapiens 2.0 Immune atlas contains 24 donors, of whom 12 had detectable regulatory T cells. Donor-level pseudobulk analysis gave a rate ratio for IL5 of 1.72 per decade (95% CI 1.15–2.58; P = 0.025; q = 0.13) and a null for IL4 (q = 0.46). IL4 also failed an ambient-RNA falsification test. These results are exploratory and are not used to support the main claims.

## Supplementary Note 3 | HRS early-warning analysis

In 45,234 HRS participants (723,744 person-waves), the deficit-accumulation index rose from 0.187 to 0.261 over follow-up and predicted mortality (HR 1.61 per SD; time-varying 1.85). Within-person variance and lag-1 autocorrelation rose before death. HRS does not measure allergy or blood-count differentials; this analysis validates the clinical trajectory of the functional dimension, not its coupling to allergic disease.

## Supplementary Note 4 | Frailty-index item audit

The UK Biobank 49-item FI includes asthma (item 28; prevalence 10.60%) and hay fever/allergic rhinitis/eczema (item 33; prevalence 19.88%); 2/49 items (4.1%) are the outcomes themselves. It also includes nine pain items (18.4%). Part of the frailty–allergy correlation is therefore definitional. The TwinGene 44-item version includes asthma and a general allergy item, so the overlap is not UKB-specific. The MHC-free and non-HLA analyses retain a signal, and the European-ancestry TAGC rg replicates the frailty–asthma correlation (0.378), but an item-excluded FI or Fried phenotype is required to quantify the residual. See Supplementary Note 8 (variance bound) and Note 10 (verification).

## Supplementary Note 5 | Shared-control caveat for the onset contrast

The childhood-onset and adult-onset asthma GWAS (Ferreira et al., 2019) used a common control set. The two rg estimates are therefore correlated, and a naive contrast z-test is not valid. We report the two estimates (0.487 versus 0.209) as suggestive and do not use a z-test in the main text.

## Supplementary Note 6 | What is not in this paper

The geroprotector/LINCS, ATP-axis, methylome and pharmacovigilance analyses are not included. They are exploratory, depend on external perturbation databases, and are being prepared separately. The T2SPD/OU formalism is not used because the parameters are not identifiable in cross-sectional data.

## Supplementary Note 7 | Phenome-wide count

Twelve of 17 endpoints were significant at FDR < 0.05. Ten of the 12 are either frailty-index items or the three primary outcomes. The only significant endpoints that are not frailty-index items were asthma with nasal polyps (rg 0.637) and chronic rhinosinusitis (0.154). The 12/17 count should therefore not be read as broad specificity.

## Supplementary Note 8 | Approximate variance contribution of the two outcome items

The 49-item FI is a sum of binary deficits divided by 49. Assuming independence and published prevalences, an item with prevalence p contributes p(1−p)/49² to the FI variance. With FI SD = 0.075 (variance 0.005625), each of items 28 and 33 contributes approximately 0.7–1.5% of FI variance for p = 0.10–0.30, or approximately 1.5–3% combined. This is a rough bound, not a substitute for individual-level variance decomposition; it suggests that the two items are unlikely to explain the entire genetic correlation, but it does not quantify the genetic contribution.

## Supplementary Note 9 | Frailty-instrument MR sensitivity

The frailty instrument is HLA-dominated, so the MR odds ratios are direction-only and the per-SD magnitude is not clinically interpretable. The IVW estimate for asthma was 3.44; MR-Egger 3.43, weighted median 4.19 and MR-PRESSO 3.38 were concordant (Supplementary Table 7). The 13-SNP non-HLA instrument gave 3.85 in FinnGen R12 and 2.38 in Pan-UKB. The direction was stable across sensitivity analyses; the estimate should not be read as a causal effect size.

## Supplementary Note 10 | Verification of the frailty-index item audit

The item numbers and prevalences were checked against the original UK Biobank 49-item list (Williams 2019) and the TwinGene 44-item list. Asthma is item 28 (prevalence 10.60%) and hay fever/allergic rhinitis/eczema is item 33 (19.88%). The nine pain items are items 37–45: chest, head/neck, back, stomach/abdominal, hip, knee, whole-body, facial and sciatica. The TwinGene version includes asthma (item 35) and a general allergy item (item 36). This verification confirms the 2/49 outcome overlap and the 9/49 pain count; it does not test the residual.

## Supplementary Note 11 | Rapid structured review of frailty instruments and allergy outcomes

This was a rapid structured review, not a systematic review or meta-analysis. We searched PubMed and reference lists for studies of frailty instruments and allergic outcomes in representative cohorts. Three studies were retained: KNHANES 2025 (16,717 participants with a Fried phenotype and 10,509 with a frailty index; self-reported allergic rhinitis; Fried OR 1.25, 95% CI 1.06–1.48; FI OR 1.59, 1.12–2.26), GAZEL 2020 (12,345 participants; Fried phenotype; current asthma; adjusted OR 2.19, 1.44–3.34) and Park 2024 (9,920 participants; K-FRAIL phenotype; physician-diagnosed asthma; OR 1.45, 1.01–2.09). No study used an item-excluded frailty index. The KNHANES within-survey comparison is compatible with construct overlap, but the FI item set differed and the estimates were not pooled. The review identifies an evidence gap, not a quantitative residual.

**Sources for Note 11**

1. Wang L, Yu L, Zhang J, Yan X, Jiang Y, Chen H. Association between frailty and the risk of allergic rhinitis: a nationwide cross-sectional study. *Sci Prog.* 2025;108(3):00368504251381587.
2. Landré B, Nadif R, Goldberg M, Gourmelen J, Zins M, Ankri J, Herr M. Asthma is associated with frailty among community-dwelling adults: the GAZEL cohort. *BMJ Open Respir Res.* 2020;7:e000526.
3. Park JM, Lee S, Chung JH. Association between Frailty and Asthma. *Medicina (Kaunas).* 2024;60(9):1479.

## Note on figures

The former Supplementary Figures 1 and 2 are now main Figures 5 and 3, respectively.
