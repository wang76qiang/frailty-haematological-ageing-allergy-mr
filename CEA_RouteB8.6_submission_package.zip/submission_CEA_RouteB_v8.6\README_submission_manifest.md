# Submission manifest — Clinical & Experimental Allergy

**Version:** v8.6  
**Date:** 21 October 2026  
**Article type:** Original Article  
**Title:** Frailty and allergic disease share genetic architecture, partly through overlapping item content  
**Running title:** Frailty, allergy and item overlap

## 1. Compliance summary

| Item | v8.6 |
|---|---|
| Main text | 3,482 words (CEA limit 5,000; internal target 3,500) |
| Abstract | 272 words (limit 300) |
| Key messages | 3 |
| Short title | 31 characters (limit 50) |
| Main display items | 5 figures + 3 tables = 8 |
| Graphical abstract | 300 dpi PNG + TIFF |
| Main figures | 600 dpi PNG, PDF, TIFF |
| References | 40, all cited in first-citation order |
| Supplementary tables | 10, all cited in order |
| Reporting checklist | Current STROBE-MR checklist included |

## 2. Core reproducible results

- FI item audit: asthma (item 28) and hay fever/allergic rhinitis/eczema (item 33) are 2/49 outcome items; 9/49 are pain items.
- FinnGen frailty–asthma rg: 0.467 (0.039); rhinitis: 0.361; atopic dermatitis: 0.246.
- TAGC European-ancestry replication: random-effects rg 0.378 (SE 0.048; P = 1.9 × 10−15); fixed-effects 0.362 (0.046; P = 3.3 × 10−15); intercept −0.003 (0.006); N = 127,669.
- Non-HLA MR: FinnGen asthma 3.85 (2.69–5.52); FinnGen rhinitis 2.67 (1.92–3.71); Pan-UKB asthma 2.38 (1.86–3.04).
- NHANES primary model: OR 1.31 (1.21–1.41) per SD; equal-weight 1.31 (1.20–1.42); leave-one-out 1.18–1.34; eosinophil-free 1.18 (1.08–1.28); eosinophil-only 1.24 (1.16–1.33).
- IgE component betas: full index 0.442; without eosinophils −0.127; eosinophils only 0.301.
- IL-18: atopic dermatitis 1.19; asthma 0.93; rhinitis 0.97.

## 3. Package inventory

- `manuscript.md`, `manuscript.docx`, `manuscript.pdf`
- `cover_letter.md`, `cover_letter.docx`
- `Figure_1`–`Figure_5` (`.png`, `.pdf`, `.tiff`)
- `graphical_abstract.png`, `graphical_abstract.tiff`
- `Table_1-3.md`, `Table_1-3.docx`
- `Supplementary_information.md`, `Supplementary_information.docx`
- `STROBE-MR_checklist.docx`
- `source_data/Figure2f_source_data.csv`
- `source_data/Figure4_source_data.csv`
- `source_data/Figure5a_source_data.csv`
- `README_submission_manifest.md`, `README_submission_manifest.docx`

## 4. Changes in v8.6 (technical revision)

- Replaced the obsolete STROBE-MR checklist (which still named a v3.2 manuscript and 8 figures) with a checklist mapped to the current sections, Tables 1–3 and Figures 1–5.
- Corrected the graphical abstract: “blood-count index without allergy items (OR 1.31)” replaces “allergy-free blood count”; “The residual remains a hypothesis” replaces the binary “not a finding” phrasing.
- Added full source citations for the three studies in Supplementary Note 11.
- Added word count, abstract count, figure count and table count to the title page.
- Added basophil (69%) to the Figure 5d Results sentence.
- Updated the AI-use disclosure to include figure preparation.
- Added a date to the cover letter.
- Replaced stale README version notes with this single manifest.
- Cleaned DOCX/PDF document properties (title, author list, subject, keywords, dates; no converter string).
- Exported the final manuscript PDF with embedded fonts and explicit metadata.

## 5. Archive and reproducibility

- Source data for Figures 2f, 4 and 5a are included in `source_data/`.
- Analysis code and derived tables: GitHub repository listed in the manuscript.
- Archived release: Zenodo concept DOI `10.5281/zenodo.22152039`.
- OSF project: `https://osf.io/f4v79`.

## 6. Scientific boundary

The item-excluded frailty index or Fried phenotype remains the decisive residual test. It requires individual-level UK Biobank data or a suitable cohort and is framed as the next step, not as a prerequisite for the current measurement claim. The blood-count index is outcome-informed and is described as a correlate, not an independent biomarker.
