# -*- coding: utf-8 -*-
"""
Nature-style composite figures and tables for the CEA frailty-allergy manuscript.
Five composite figures (4-6 panels each), three tables.
Only panel letters are placed inside figures; no suptitles or panel titles.
"""
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Patch
from matplotlib.colors import ListedColormap
from PIL import Image

ROOT = Path(__file__).resolve().parent.parent
T = ROOT / "derived_tables"
OUT_F = ROOT / "code" / "outputs" / "figures"
OUT_T = ROOT / "code" / "outputs" / "tables"
OUT_F.mkdir(parents=True, exist_ok=True)
OUT_T.mkdir(parents=True, exist_ok=True)

# ------------------------------------------------------------------ style
plt.rcParams.update({
    "font.family": "Arial",
    "font.size": 7,
    "axes.labelsize": 7,
    "axes.titlesize": 7,
    "xtick.labelsize": 6,
    "ytick.labelsize": 6,
    "legend.fontsize": 6,
    "axes.linewidth": 0.6,
    "xtick.major.width": 0.6,
    "ytick.major.width": 0.6,
    "xtick.major.size": 2.5,
    "ytick.major.size": 2.5,
    "axes.spines.top": False,
    "axes.spines.right": False,
    "figure.dpi": 150,
    "savefig.dpi": 600,
    "savefig.bbox": "tight",
    "savefig.pad_inches": 0.02,
})

C_FRAIL = "#D55E00"
C_BLUE = "#0072B2"
C_SKY = "#56B4E9"
C_GREEN = "#009E73"
C_PINK = "#CC79A7"
C_ORANGE = "#E69F00"
C_GREY = "#7F7F7F"
C_LIGHT = "#BDBDBD"
C_ASTHMA = "#0072B2"
C_RHIN = "#009E73"
C_AD = "#CC79A7"

INSTR = ["Frailty", "GrimAge", "Hannum", "IEAA", "PhenoAge"]
INST_COL = {"Frailty": C_FRAIL, "GrimAge": C_BLUE, "Hannum": C_SKY,
            "IEAA": C_GREEN, "PhenoAge": C_PINK}
OUTCOMES = ["Asthma", "Allergic rhinitis", "Atopic dermatitis"]
OUT_COL = {"Asthma": C_ASTHMA, "Allergic rhinitis": C_RHIN, "Atopic dermatitis": C_AD}


def panel(ax, letter, x=-0.14, y=1.10):
    ax.text(x, y, letter, transform=ax.transAxes, fontsize=9,
            fontweight="bold", va="top", ha="left", clip_on=False)


def clean(ax):
    ax.tick_params(direction="out", length=2.5, width=0.6, pad=1.5)


def save(fig, stem):
    fig.savefig(OUT_F / f"{stem}.png", dpi=600)
    fig.savefig(OUT_F / f"{stem}.pdf")
    im = Image.open(OUT_F / f"{stem}.png").convert("RGB")
    im.save(OUT_F / f"{stem}.tiff", compression="tiff_lzw", dpi=(600, 600))
    plt.close(fig)
    print("saved", stem)


def expand_err(vals, lo, hi):
    vals, lo, hi = np.asarray(vals, float), np.asarray(lo, float), np.asarray(hi, float)
    return np.vstack([vals - lo, hi - vals])


# ================================================================== data
strength = pd.read_csv(T / "ST_new_instrument_strength.csv")
strength["instrument"] = pd.Categorical(strength.instrument, INSTR, ordered=True)
strength = strength.sort_values("instrument")

rg_long = pd.read_csv(T / "ST_new_canonical_instrument_rg_long.csv")
mat = pd.DataFrame(np.eye(5), index=INSTR, columns=INSTR, dtype=float)
for _, r in rg_long.iterrows():
    mat.loc[r.trait1, r.trait2] = r.rg
    mat.loc[r.trait2, r.trait1] = r.rg

inter = pd.read_csv(T / "ST_new_instrument_rg_intercepts.csv")
inter["kind"] = np.where(inter.pair.str.startswith("Frailty"), "frailty", "clock")

out = pd.read_csv(T / "ST_new_canonical_outcome_rg.csv")
out["instrument"] = pd.Categorical(out.instrument, INSTR, ordered=True)
out_p = out.pivot(index="instrument", columns="outcome", values="rg").loc[INSTR, OUTCOMES]
out_se = out.pivot(index="instrument", columns="outcome", values="rg_se").loc[INSTR, OUTCOMES]

tagc = pd.read_csv(T / "ST_new_TAGC_replication.csv")
onset = pd.read_csv(T / "ST97_r8_onset_ldsc_rg.csv")
onset_f = onset[onset.trait1 == "Frailty"].set_index("trait2")
coup = pd.read_csv(T / "COUP01_dimension_disease_coupling_rg.csv")
coup = coup[coup.exposure == "Frailty"].copy()

fi_audit = pd.read_csv(T / "ST_new_FI_item_audit.csv")
fi_ver = pd.read_csv(T / "ST_new_FI_verification.csv")
fi_ver.columns = [c.strip().lstrip("\ufeff") for c in fi_ver.columns]

age = pd.read_csv(T / "ST_new_nhanes_weighted_age_curve.csv")
# convert raw I to SD units using analysis-sample SD 0.5759
age["mean_sd"] = age.weighted_mean / 0.5759
age["se_sd"] = age.se / 0.5759

l1 = pd.read_csv(T / "ST_new_equal_weight_leave_one_out.csv")
eq = l1[l1.dropped.str.startswith("none")].iloc[0]

il18 = pd.read_csv(T / "ST_new_IL18_outcome_specific.csv")
il18_ivw = il18[il18.snp == "IVW"].set_index("outcome")

# IL18 assay ORs: SCALLOP/Luminex from manuscript; HELIC computed from ST127
helic = pd.read_csv(T / "ST127_pqtl_helic_il18.csv")
helic = helic[helic.snp != "(IVW)"].copy()
w = 1 / helic.wald_se.astype(float) ** 2
helic_b = np.sum(helic.wald_logor.astype(float) * w) / np.sum(w)
helic_se = np.sqrt(1 / np.sum(w))
helic_or, helic_lo, helic_hi = np.exp(helic_b), np.exp(helic_b - 1.96 * helic_se), np.exp(helic_b + 1.96 * helic_se)
assay = pd.DataFrame({
    "assay": ["SCALLOP", "Luminex", "HELIC", "Pooled"],
    "OR": [1.1907, 1.1641, helic_or, 1.1866],
    "lo": [1.1297, 1.1056, helic_lo, 1.1471],
    "hi": [1.2549, 1.2259, helic_hi, 1.2274],
})
coloc = pd.DataFrame({
    "protein": ["IL18", "TNFSF14", "TNF", "TRAIL"],
    "pp4": [0.9682, 0.9756, 0.0100, 0.2822],
})
lung = pd.read_csv(T / "ATP01_lung_atp_axis_colocalization.csv")
lung = lung.sort_values("IL18_pct", ascending=False).head(8)

# ================================================================== FIGURE 1
fig = plt.figure(figsize=(7.2, 4.7))
gs = fig.add_gridspec(2, 3, hspace=0.42, wspace=0.52)

# a matrix
ax = fig.add_subplot(gs[0, 0])
im = ax.imshow(mat.values, cmap="RdBu_r", vmin=-0.35, vmax=1.0, aspect="equal")
ax.set_xticks(range(5)); ax.set_yticks(range(5))
ax.set_xticklabels(INSTR, rotation=40, ha="right")
ax.set_yticklabels(INSTR)
for i in range(6):
    ax.axhline(i - 0.5, color="white", lw=0.8)
    ax.axvline(i - 0.5, color="white", lw=0.8)
cb = fig.colorbar(im, ax=ax, fraction=0.046, pad=0.03)
cb.set_label("rg", fontsize=6); cb.ax.tick_params(labelsize=5)
panel(ax, "a")

# b h2
ax = fig.add_subplot(gs[0, 1])
x = np.arange(5); h = strength.h2.values; se = strength.h2_se.values
ax.bar(x, h, yerr=se, color=[INST_COL[i] for i in INSTR], width=0.65,
       capsize=2, error_kw={"elinewidth": 0.6, "ecolor": "black"})
ax.set_xticks(x); ax.set_xticklabels(INSTR, rotation=35, ha="right")
ax.set_ylabel("SNP h²")
ax.set_ylim(0, 0.24)
clean(ax); panel(ax, "b")

# c FI composition as a 7 x 7 waffle (49 items)
ax = fig.add_subplot(gs[0, 2])
waffle = np.zeros((7, 7), dtype=int)
waffle.flat[:2] = 1       # outcome items
waffle.flat[2:11] = 2      # pain items
waffle.flat[11:] = 0       # other
waffle_cmap = ListedColormap([C_LIGHT, C_FRAIL, C_ORANGE])
ax.imshow(waffle, cmap=waffle_cmap, vmin=0, vmax=2, aspect="equal")
for i in range(8):
    ax.axhline(i - 0.5, color="white", lw=1.1)
    ax.axvline(i - 0.5, color="white", lw=1.1)
ax.set_xticks([]); ax.set_yticks([]); ax.set_xlim(-0.5, 6.5); ax.set_ylim(6.5, -0.5)
for spine in ax.spines.values():
    spine.set_visible(False)
handles = [Patch(facecolor=C_FRAIL, edgecolor="none", label="Outcome"),
           Patch(facecolor=C_ORANGE, edgecolor="none", label="Pain"),
           Patch(facecolor=C_LIGHT, edgecolor="none", label="Other")]
ax.legend(handles=handles, frameon=False, loc="upper center", bbox_to_anchor=(0.5, -0.02),
          ncol=3, handlelength=0.8, columnspacing=0.8, fontsize=5.8, handletextpad=0.3)
panel(ax, "c")

# d rg distributions
ax = fig.add_subplot(gs[1, 0])
clock_rg = rg_long[(rg_long.trait1 != "Frailty") & (rg_long.trait2 != "Frailty")].rg.values
frail_rg = rg_long[(rg_long.trait1 == "Frailty") | (rg_long.trait2 == "Frailty")].rg.values
rng = np.random.default_rng(2)
for i, vals, col in [(0, clock_rg, C_BLUE), (1, frail_rg, C_FRAIL)]:
    jit = rng.uniform(-0.10, 0.10, len(vals))
    q1, q3 = np.percentile(vals, [25, 75])
    ax.fill_betweenx([q1, q3], i - 0.26, i + 0.26, color=col, alpha=0.12, lw=0)
    ax.scatter(i + jit, vals, s=16, color=col, alpha=0.9, linewidth=0)
    ax.hlines(np.mean(vals), i - 0.22, i + 0.22, color="black", lw=0.8)
ax.set_xticks([0, 1]); ax.set_xticklabels(["Clock–clock", "Frailty–clock"])
ax.set_ylabel("rg"); ax.axhline(0, color="grey", lw=0.5, ls=":")
clean(ax); panel(ax, "d")

# e intercepts
ax = fig.add_subplot(gs[1, 1])
cc = inter[inter.kind == "clock"].gcov_int.values
fc = inter[inter.kind == "frailty"].gcov_int.values
for i, vals, col in [(0, cc, C_BLUE), (1, fc, C_FRAIL)]:
    jit = rng.uniform(-0.10, 0.10, len(vals))
    q1, q3 = np.percentile(vals, [25, 75])
    ax.fill_betweenx([q1, q3], i - 0.26, i + 0.26, color=col, alpha=0.12, lw=0)
    ax.scatter(i + jit, vals, s=16, color=col, alpha=0.9, linewidth=0)
    ax.hlines(np.mean(vals), i - 0.22, i + 0.22, color="black", lw=0.8)
ax.set_xticks([0, 1]); ax.set_xticklabels(["Clock–clock", "Frailty–clock"])
ax.set_ylabel("Cross-trait intercept"); ax.axhline(0, color="grey", lw=0.5, ls=":")
clean(ax); panel(ax, "e")

# f prevalence
ax = fig.add_subplot(gs[1, 2])
prev = [10.60, 19.88]
ax.bar([0, 1], prev, color=[C_FRAIL, C_ORANGE], width=0.55)
ax.set_xticks([0, 1]); ax.set_xticklabels(["Asthma\n(item 28)", "Hay fever/\neczema (item 33)"])
ax.set_ylabel("Prevalence (%)"); ax.set_ylim(0, 24)
clean(ax); panel(ax, "f")

save(fig, "Figure_1_measurement_architecture")

# ================================================================== FIGURE 2
fig = plt.figure(figsize=(7.2, 4.9))
gs = fig.add_gridspec(2, 3, hspace=0.42, wspace=0.62)

# a outcome heatmap
ax = fig.add_subplot(gs[0, 0])
im = ax.imshow(out_p.values, cmap="RdBu_r", vmin=-0.15, vmax=0.50, aspect="auto")
ax.set_xticks(range(3)); ax.set_xticklabels(["Asthma", "Rhinitis", "AD"], rotation=35, ha="right")
ax.set_yticks(range(5)); ax.set_yticklabels(INSTR)
for i in range(6):
    ax.axhline(i - 0.5, color="white", lw=0.8)
for j in range(4):
    ax.axvline(j - 0.5, color="white", lw=0.8)
cb = fig.colorbar(im, ax=ax, fraction=0.046, pad=0.03)
cb.set_label("rg", fontsize=6); cb.ax.tick_params(labelsize=5)
panel(ax, "a")

# b forest frailty vs clocks
ax = fig.add_subplot(gs[0, 1])
for yi, inst in enumerate(INSTR):
    for off, oc in [(0.17, "Asthma"), (-0.17, "Allergic rhinitis")]:
        v = out_p.loc[inst, oc]; s = out_se.loc[inst, oc]
        ax.errorbar(v, yi + off, xerr=1.96 * s, fmt="o", ms=3.0,
                    color=OUT_COL[oc], ecolor=OUT_COL[oc], elinewidth=0.6, capsize=1.5)
ax.set_yticks(range(5)); ax.set_yticklabels(INSTR)
ax.set_xlabel("rg"); ax.axvline(0, color="grey", lw=0.5, ls=":")
ax.set_xlim(-0.10, 0.60)
handles = [Line2D([0], [0], marker="o", color="none", markerfacecolor=OUT_COL[o],
                  markersize=3, label=o) for o in ["Asthma", "Allergic rhinitis"]]
ax.legend(handles=handles, frameon=False, loc="lower left", handletextpad=0.2)
clean(ax); panel(ax, "b")

# c TAGC
ax = fig.add_subplot(gs[0, 2])
tagc_plot = tagc[tagc.model.isin(["random", "fixed"])].copy()
rows = [("FinnGen R12", 0.4672, 0.0393, C_FRAIL),
        ("TAGC random", float(tagc_plot[tagc_plot.model == "random"].rg.iloc[0]),
         float(tagc_plot[tagc_plot.model == "random"].se.iloc[0]), C_BLUE),
        ("TAGC fixed", float(tagc_plot[tagc_plot.model == "fixed"].rg.iloc[0]),
         float(tagc_plot[tagc_plot.model == "fixed"].se.iloc[0]), C_SKY)]
for yi, (lab, v, s, col) in enumerate(rows):
    ax.errorbar(v, yi, xerr=1.96 * s, fmt="o", ms=3.5, color=col, ecolor=col,
                elinewidth=0.7, capsize=2)
ax.set_yticks(range(3)); ax.set_yticklabels([r[0] for r in rows])
ax.set_xlabel("rg"); ax.axvline(0, color="grey", lw=0.5, ls=":")
ax.set_xlim(0.25, 0.52)
clean(ax); panel(ax, "c")

# d AD unresolved (all instruments)
ax = fig.add_subplot(gs[1, 0])
for yi, inst in enumerate(INSTR):
    v = out_p.loc[inst, "Atopic dermatitis"]; se = out_se.loc[inst, "Atopic dermatitis"]
    ax.errorbar(v, yi, xerr=1.96 * se, fmt="o", ms=3.0,
                color=INST_COL[inst], ecolor=INST_COL[inst], elinewidth=0.6, capsize=1.5)
ax.set_yticks(range(5)); ax.set_yticklabels(INSTR)
ax.set_xlabel("rg (atopic dermatitis)"); ax.axvline(0, color="grey", lw=0.5, ls=":")
ax.set_xlim(0.0, 0.50)
clean(ax); panel(ax, "d")

# e paired frailty vs best clock
ax = fig.add_subplot(gs[1, 1])
clocks = ["GrimAge", "Hannum", "IEAA", "PhenoAge"]
for yi, oc in enumerate(OUTCOMES):
    fv = out_p.loc["Frailty", oc]; fs = out_se.loc["Frailty", oc]
    cvals = out_p.loc[clocks, oc]
    best = cvals.idxmax(); cv = cvals.loc[best]; cs = out_se.loc[best, oc]
    ax.plot([cv, fv], [yi, yi], color=C_LIGHT, lw=1.0, zorder=1)
    ax.errorbar(cv, yi, xerr=1.96 * cs, fmt="o", ms=3.0, color=C_GREY,
                ecolor=C_GREY, elinewidth=0.6, capsize=1.5, zorder=2)
    ax.errorbar(fv, yi, xerr=1.96 * fs, fmt="o", ms=3.2, color=C_FRAIL,
                ecolor=C_FRAIL, elinewidth=0.6, capsize=1.5, zorder=3)
ax.set_yticks(range(3)); ax.set_yticklabels(["Asthma", "Rhinitis", "AD"])
ax.set_xlabel("rg"); ax.axvline(0, color="grey", lw=0.5, ls=":")
ax.set_xlim(0.0, 0.55)
handles = [Line2D([0], [0], marker="o", color="none", markerfacecolor=C_FRAIL, markersize=3, label="Frailty"),
           Line2D([0], [0], marker="o", color="none", markerfacecolor=C_GREY, markersize=3, label="Best clock")]
ax.legend(handles=handles, frameon=False, loc="lower center", bbox_to_anchor=(0.5, 1.02), ncol=2, handletextpad=0.2, fontsize=5.5)
clean(ax); panel(ax, "e")

# f non-HLA MR
ax = fig.add_subplot(gs[1, 2])
mr_rows = [("FinnGen asthma", 3.8527, 2.6889, 5.5202, C_FRAIL),
           ("FinnGen rhinitis", 2.6706, 1.9201, 3.7144, C_FRAIL),
           ("Pan-UKB asthma", 2.3810, 1.8620, 3.0447, C_BLUE)]
for yi, (lab, v, lo, hi, col) in enumerate(mr_rows):
    ax.errorbar(v, yi, xerr=[[v - lo], [hi - v]], fmt="o", ms=3.5, color=col,
                ecolor=col, elinewidth=0.7, capsize=2)
ax.set_yticks(range(len(mr_rows))); ax.set_yticklabels([r[0] for r in mr_rows])
ax.set_xlabel("OR (non-HLA instrument)"); ax.axvline(1, color="grey", lw=0.5, ls=":")
ax.set_xlim(1.2, 6.0); ax.set_xticks([2, 3, 4, 5, 6])
clean(ax); panel(ax, "f")

save(fig, "Figure_2_coupling_replication")

# ================================================================== FIGURE 3
fig = plt.figure(figsize=(7.2, 4.2))
gs = fig.add_gridspec(2, 2, hspace=0.35, wspace=0.52)

# a onset
ax = fig.add_subplot(gs[0, 0])
adult = float(onset_f.loc["ADULT_ONSET_ASTHMA", "rg"])
adult_se = float(onset_f.loc["ADULT_ONSET_ASTHMA", "rg_se"])
child = float(onset_f.loc["CHILD_ONSET_ASTHMA", "rg"])
child_se = float(onset_f.loc["CHILD_ONSET_ASTHMA", "rg_se"])
ax.plot([0, 1], [adult, child], color=C_LIGHT, lw=1.2, zorder=1)
for xi, v, se, col in [(0, adult, adult_se, C_FRAIL), (1, child, child_se, C_GREY)]:
    ax.errorbar(xi, v, yerr=1.96 * se, fmt="o", ms=4.2, color=col, ecolor=col,
                elinewidth=0.8, capsize=2.5, zorder=3)
ax.set_xticks([0, 1]); ax.set_xticklabels(["Adult", "Childhood"])
ax.set_ylabel("rg with frailty")
ax.set_xlim(-0.35, 1.35); ax.set_ylim(0, 0.60)
clean(ax); panel(ax, "a")

# b phenome scan
ax = fig.add_subplot(gs[0, 1])
label_map = {
    "ALLERG_ASTHMA": "Asthma", "ALLERG_RHINITIS": "Rhinitis", "L12_ATOPIC": "Atopic dermatitis",
    "ASTHMA_NAS": "Asthma + NP", "J10_PNEUMONIA": "Pneumonia", "M13_RHEUMA": "Rheumatoid arthritis",
    "L12_PSORIASIS": "Psoriasis", "I9_MI_STRICT": "Myocardial infarction",
    "F5_DEPRESSIO": "Depression", "F5_DEMENTIA": "Dementia", "ST19_FRACT_FEMUR": "Femur fracture",
    "AB1_OTHER_SEPSIS": "Sepsis", "K11_UC_STRICT2": "Ulcerative colitis",
    "T1D": "Type 1 diabetes", "FOOD_ALLERGY": "Food allergy",
    "CHRONNAS": "Chronic rhinosinusitis",
    "ANAPH_SHOCK_ADVER_EFFECT_CORRE_DRUG_MEDICAM_PROPE_ADMINISTE": "Anaphylaxis",
}
primary = {"ALLERG_ASTHMA", "ALLERG_RHINITIS", "L12_ATOPIC"}
fi_items = {"ASTHMA_NAS", "J10_PNEUMONIA", "M13_RHEUMA", "L12_PSORIASIS",
            "I9_MI_STRICT", "F5_DEPRESSIO", "ST19_FRACT_FEMUR"}
indep = {"CHRONNAS"}
cat_col = {"Primary outcome": C_FRAIL, "FI item/subtype": C_BLUE,
           "Independent": C_GREEN, "Other": C_LIGHT}
cph = coup.copy()
cph["label"] = cph.endpoint.map(label_map)
cph["cat"] = np.where(cph.endpoint.isin(primary), "Primary outcome",
             np.where(cph.endpoint.isin(fi_items), "FI item/subtype",
             np.where(cph.endpoint.isin(indep), "Independent", "Other")))
cph = cph.sort_values("rg")
for yi, (_, r) in enumerate(cph.iterrows()):
    ax.errorbar(r.rg, yi, xerr=1.96 * r.se, fmt="o", ms=2.8,
                color=cat_col[r["cat"]], ecolor=cat_col[r["cat"]], elinewidth=0.5, capsize=1.2)
ax.set_yticks(range(len(cph))); ax.set_yticklabels(cph.label, fontsize=5.6)
ax.set_xlabel("rg"); ax.axvline(0, color="grey", lw=0.5, ls=":")
ax.set_xlim(-0.15, 0.75)
handles = [Line2D([0], [0], marker="o", color="none", markerfacecolor=v, markersize=3, label=k)
           for k, v in cat_col.items()]
ax.legend(handles=handles, frameon=False, loc="lower right", fontsize=5.2, handletextpad=0.2)
clean(ax); panel(ax, "b")

# c non-FI endpoints
ax = fig.add_subplot(gs[1, 0])
nf = cph[cph.endpoint.isin(["ASTHMA_NAS", "AB1_OTHER_SEPSIS", "CHRONNAS"])].sort_values("rg")
for yi, (_, r) in enumerate(nf.iterrows()):
    col = C_FRAIL if r.endpoint == "ASTHMA_NAS" else (C_GREY if r.endpoint == "AB1_OTHER_SEPSIS" else C_GREEN)
    ax.errorbar(r.rg, yi, xerr=1.96 * r.se, fmt="o", ms=3.5,
                color=col, ecolor=col, elinewidth=0.7, capsize=2)
ax.set_yticks(range(len(nf))); ax.set_yticklabels(nf.label)
ax.set_xlabel("rg"); ax.axvline(0, color="grey", lw=0.5, ls=":")
ax.set_xlim(0, 0.72)
clean(ax); panel(ax, "c")

# d variance bound
ax = fig.add_subplot(gs[1, 1])
v = [0.70, 1.18, 1.88]
ax.bar([0, 1, 2], v, color=[C_FRAIL, C_ORANGE, C_GREY], width=0.55)
ax.set_xticks([0, 1, 2]); ax.set_xticklabels(["Item 28", "Item 33", "Combined"], rotation=20, ha="right")
ax.set_ylabel("FI variance (%)"); ax.set_ylim(0, 2.4)
clean(ax); panel(ax, "d")

save(fig, "Figure_3_residual_triangulation")

# ================================================================== FIGURE 4
fig = plt.figure(figsize=(7.2, 4.3))
gs = fig.add_gridspec(2, 2, hspace=0.40, wspace=0.48)

# a age curve
ax = fig.add_subplot(gs[0, 0])
ax.errorbar(age.age_decade + 5, age.mean_sd, yerr=1.96 * age.se_sd,
            fmt="o-", ms=3.5, lw=0.8, color=C_FRAIL, ecolor=C_FRAIL,
            elinewidth=0.6, capsize=2)
ax.axhline(0, color="grey", lw=0.5, ls=":")
ax.set_xlabel("Age (years)"); ax.set_ylabel("Index (SD)")
clean(ax); panel(ax, "a")

# b OR forest
ax = fig.add_subplot(gs[0, 1])
rows = [("Primary", 1.3069, 1.2099, 1.4117, C_FRAIL),
        ("Equal-weight", 1.3069, 1.1988, 1.4247, C_BLUE),
        ("Leave-one-out", 1.2586, 1.1768, 1.3403, C_SKY),
        ("Eosinophil-free", 1.1768, 1.0806, 1.2815, C_GREEN),
        ("Eosinophil-only", 1.2433, 1.1583, 1.3345, C_PINK)]
for yi, (lab, v, lo, hi, col) in enumerate(rows):
    if lab == "Leave-one-out":
        ax.hlines(yi, lo, hi, color=col, lw=2.0)
        ax.plot(v, yi, "o", color=col, ms=3.2)
    else:
        ax.errorbar(v, yi, xerr=[[v - lo], [hi - v]], fmt="o", ms=3.2,
                    color=col, ecolor=col, elinewidth=0.7, capsize=2)
ax.set_yticks(range(len(rows))); ax.set_yticklabels([r[0] for r in rows])
ax.set_xlabel("OR per SD"); ax.axvline(1, color="grey", lw=0.5, ls=":")
ax.set_xlim(1.0, 1.48)
clean(ax); panel(ax, "b")

# c component ORs
ax = fig.add_subplot(gs[1, 0])
vals = [1.3069, 1.1768, 1.2433]; lo = [1.2099, 1.0806, 1.1583]; hi = [1.4117, 1.2815, 1.3345]
ax.bar([0, 1, 2], vals, yerr=expand_err(vals, lo, hi), color=[C_FRAIL, C_GREEN, C_PINK],
       width=0.55, capsize=2, error_kw={"elinewidth": 0.6, "ecolor": "black"})
ax.set_xticks([0, 1, 2]); ax.set_xticklabels(["Full", "Eos-free", "Eos-only"], rotation=20, ha="right")
ax.set_ylabel("OR per SD"); ax.axhline(1, color="grey", lw=0.5, ls=":")
ax.set_ylim(0.9, 1.5)
clean(ax); panel(ax, "c")

# d IgE
ax = fig.add_subplot(gs[1, 1])
vals = [0.4416, -0.1274, 0.3010]; lo = [0.3641, -0.2815, 0.2576]; hi = [0.5192, 0.0267, 0.3443]
ax.bar([0, 1, 2], vals, yerr=expand_err(vals, lo, hi), color=[C_FRAIL, C_GREEN, C_PINK],
       width=0.55, capsize=2, error_kw={"elinewidth": 0.6, "ecolor": "black"})
ax.axhline(0, color="grey", lw=0.5, ls=":")
ax.set_xticks([0, 1, 2]); ax.set_xticklabels(["Full", "Eos-free", "Eos-only"], rotation=20, ha="right")
ax.set_ylabel("β (log-IgE)"); ax.set_ylim(-0.35, 0.60)
clean(ax); panel(ax, "d")

save(fig, "Figure_4_blood_count_index")

# ================================================================== FIGURE 5
fig = plt.figure(figsize=(7.2, 4.3))
gs = fig.add_gridspec(2, 2, hspace=0.40, wspace=0.50)

# a assay OR
ax = fig.add_subplot(gs[0, 0])
for yi, r in assay.iterrows():
    col = C_FRAIL if r.assay == "Pooled" else C_BLUE
    ax.errorbar(r.OR, yi, xerr=[[r.OR - r.lo], [r.hi - r.OR]], fmt="o", ms=3.2,
                color=col, ecolor=col, elinewidth=0.7, capsize=2)
ax.set_yticks(range(len(assay))); ax.set_yticklabels(assay.assay)
ax.set_xlabel("OR (IL-18)"); ax.axvline(1, color="grey", lw=0.5, ls=":")
ax.set_xlim(1.0, 1.35)
clean(ax); panel(ax, "a")

# b outcome-specific
ax = fig.add_subplot(gs[0, 1])
rows = [("Atopic dermatitis", 1.1907, 1.1200, 1.2656, C_AD),
        ("Asthma", 0.93, 0.85, 1.01, C_ASTHMA),
        ("Allergic rhinitis", 0.97, 0.90, 1.06, C_RHIN)]
for yi, (lab, v, lo, hi, col) in enumerate(rows):
    ax.errorbar(v, yi, xerr=[[v - lo], [hi - v]], fmt="o", ms=3.2,
                color=col, ecolor=col, elinewidth=0.7, capsize=2)
ax.set_yticks(range(3)); ax.set_yticklabels([r[0] for r in rows])
ax.set_xlabel("OR"); ax.axvline(1, color="grey", lw=0.5, ls=":")
ax.set_xlim(0.80, 1.32)
clean(ax); panel(ax, "b")

# c coloc (lollipop)
ax = fig.add_subplot(gs[1, 0])
cplot = coloc.sort_values("pp4", ascending=True)
for yi, (_, r) in enumerate(cplot.iterrows()):
    col = C_FRAIL if r.protein == "IL18" else (C_BLUE if r.protein == "TNFSF14" else C_LIGHT)
    ax.hlines(yi, 0, r.pp4, color=col, lw=1.2)
    ax.plot(r.pp4, yi, "o", color=col, ms=4)
ax.set_yticks(range(4)); ax.set_yticklabels(cplot.protein)
ax.set_xlabel("PP.H4"); ax.set_xlim(0, 1.05)
clean(ax); panel(ax, "c")

# d lung atlas
ax = fig.add_subplot(gs[1, 1])
lung_plot = lung.set_index("cell_type")[["IL18_pct", "IL33_pct"]]
im = ax.imshow(lung_plot.values, cmap="viridis", aspect="auto", vmin=0, vmax=80)
ax.set_xticks([0, 1]); ax.set_xticklabels(["IL18", "IL33"])
ax.set_yticks(range(len(lung_plot))); ax.set_yticklabels(lung_plot.index, fontsize=5.5)
cb = fig.colorbar(im, ax=ax, fraction=0.046, pad=0.03)
cb.set_label("% expressing", fontsize=6); cb.ax.tick_params(labelsize=5)
clean(ax); panel(ax, "d")

save(fig, "Figure_5_IL18_interface")
print("figures complete")
