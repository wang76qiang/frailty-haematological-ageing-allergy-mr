# Submission manifest — Clinical & Experimental Allergy

**Version:** v8.8  
**Date:** 21 October 2026  
**Article type:** Original Article  
**Title:** Frailty and allergic disease share genetic architecture, partly through overlapping item content  
**Running title:** Frailty, allergy and item overlap

## 1. Compliance summary

| Item | v8.7 |
|---|---|
| Main text | 3,455 words by Word (CEA limit 3,500; 45-word margin) |
| Abstract | 286 words by Word (limit 300) |
| Key messages | 3 |
| Short title | 31 characters (limit 50) |
| Main display items | 5 figures + 3 tables = 8 |
| Graphical abstract | 300 dpi PNG + TIFF |
| Main figures | 600 dpi PNG, PDF, TIFF |
| References | 40, all cited in first-citation order |
| Supplementary tables | 10, all cited in order |
| Reporting checklist | Current STROBE-MR checklist included |

## 2. Core reproducible results

- FI item audit: asthma (item 28) and hay fever/allergic rhinitis/eczema (item 33) are 2/49 outcome items; 9/49 are pain items.
- FinnGen frailty–asthma rg: 0.467 (0.039); rhinitis: 0.361; atopic dermatitis: 0.246.
- TAGC European-ancestry replication: random-effects rg 0.378 (SE 0.048; P = 1.9 × 10−15); fixed-effects 0.362 (0.046; P = 3.3 × 10−15); intercept −0.003 (0.006); N = 127,669.
- Non-HLA MR: FinnGen asthma 3.85 (2.69–5.52); FinnGen rhinitis 2.67 (1.92–3.71); Pan-UKB asthma 2.38 (1.86–3.04).
- NHANES primary model: OR 1.31 (1.21–1.41) per SD; equal-weight 1.31 (1.20–1.42); leave-one-out 1.18–1.34; eosinophil-free 1.18 (1.08–1.28); eosinophil-only 1.24 (1.16–1.33).
- IgE component betas: full index 0.442; without eosinophils −0.127; eosinophils only 0.301.
- IL-18: atopic dermatitis 1.19; asthma 0.93; rhinitis 0.97.

## 3. Package inventory

- `manuscript.md`, `manuscript.docx`, `manuscript.pdf`
- `cover_letter.md`, `cover_letter.docx`
- `Figure_1`–`Figure_5` (`.png`, `.pdf`, `.tiff`)
- `graphical_abstract.png`, `graphical_abstract.tiff`
- `Table_1-3.md`, `Table_1-3.docx`
- `Supplementary_information.md`, `Supplementary_information.docx`
- `STROBE-MR_checklist.docx`
- `code/make_figures.py`, `code/make_tables.py`, `code/README_code.md`, `code/requirements.txt`
- `derived_tables/` (22 CSV tables plus README, including all figure/table inputs)
- `source_data/Figure2f_source_data.csv`, `Figure4_source_data.csv`, `Figure5a_source_data.csv`
- `README_submission_manifest.md`, `README_submission_manifest.docx`
- `README_derived_tables.md` inside `derived_tables/`

## 4. Changes in v8.8

- Corrected the archive count to 22 CSV tables plus README.
- Repeated the Table 2 header on continuation pages.
- Added current figure/table code and all numerical inputs to the submission archive; `code/make_figures.py` and `code/make_tables.py` both run from the package root.
- Added “LD score regression and Mendelian randomisation” to the abstract Methods, satisfying STROBE-MR item 1 without changing the main text.
- Corrected the compliance table: CEA Original Article limit is **3,500 words**, not 5,000.
- Replaced the earlier 3,482/272 counts with Word counts (3,455 main; 286 abstract).
- Updated the STROBE-MR checklist to v8.7.
- Kept the corrected graphical abstract, Note 11 sources, basophil sentence, title-page metrics, AI disclosure, cover-letter date and clean DOCX/PDF metadata from v8.6.

## 5. Archive and reproducibility

- Analysis code and derived tables are included in `code/` and `derived_tables/` in this package and in the versioned archive.
- Primary GWAS summary statistics and individual-level UK Biobank/NHANES data are not redistributed; access conditions are given in the manuscript.
- Zenodo concept DOI: `10.5281/zenodo.22152039`.
- GitHub repository: https://github.com/wang76qiang/frailty-haematological-ageing-allergy-mr
- OSF analysis plan: https://osf.io/f4v79

## 6. Scientific boundary

The item-excluded frailty index or Fried phenotype remains the decisive residual test. It requires individual-level UK Biobank data or a suitable cohort and is framed as the next step, not as a prerequisite for the current measurement claim. The blood-count index is outcome-informed and is described as a correlate, not an independent biomarker.
