# Reproducibility code for the CEA v8.7 figures and tables

Run from the package root:

```bash
python code/make_figures.py
python code/make_tables.py
```

Outputs are written to `code/outputs/figures/` and `code/outputs/tables/`.

## Inputs

All numerical inputs used by the scripts are in `derived_tables/`:

- `ST_new_*` canonical LDSC, FI audit, equal-weight, NHANES, TAGC, IL-18 and instrument-strength tables;
- `COUP01_dimension_disease_coupling_rg.csv` (phenome-wide coupling);
- `ATP01_lung_atp_axis_colocalization.csv` (lung atlas);
- `ST97_r8_onset_ldsc_rg.csv` (adult-versus-childhood onset);
- `ST127_pqtl_helic_il18.csv` (HELIC IL-18 pQTL);
- `Figure2f_source_data.csv`, `Figure4_source_data.csv`, `Figure5a_source_data.csv`.

The scripts reproduce the five composite figures and three main tables from these derived tables. The primary GWAS summary statistics and individual-level UK Biobank/NHANES data are not redistributed; access conditions are given in the manuscript.

## Environment

Python 3.11+ with the packages in `requirements.txt`. Figure output uses Matplotlib with Arial; minor typographic differences may occur if Arial is unavailable.
