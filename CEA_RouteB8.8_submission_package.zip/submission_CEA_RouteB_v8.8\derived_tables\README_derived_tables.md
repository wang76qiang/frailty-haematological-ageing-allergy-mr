# Derived tables

This folder contains the derived tables used by `code/make_figures.py` and `code/make_tables.py`.

- Canonical LDSC instrument–instrument and instrument–outcome correlations
- MHC-free / non-HLA sensitivity summaries
- FI item audit and verification
- TAGC European-ancestry replication
- NHANES blood-count index models and age curve
- Equal-weight and leave-one-out estimates
- IL-18 outcome-specific estimates
- Lung atlas and HELIC pQTL inputs
- Figure 2f, Figure 4 and Figure 5a source data

The underlying GWAS summary statistics are available from the sources listed in the manuscript. Individual-level UK Biobank and NHANES data are not redistributed.
