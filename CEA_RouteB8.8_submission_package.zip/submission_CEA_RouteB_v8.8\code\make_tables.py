# -*- coding: utf-8 -*-
"""Nature-style tables (3) for the CEA frailty-allergy manuscript."""
from pathlib import Path
import pandas as pd
from docx import Document
from docx.shared import Pt, Inches, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

ROOT = Path(__file__).resolve().parent.parent
T = ROOT / "derived_tables"
OUT = ROOT / "code" / "outputs" / "tables"
OUT.mkdir(parents=True, exist_ok=True)

outcome = pd.read_csv(T / "ST_new_canonical_outcome_rg.csv")
tagc = pd.read_csv(T / "ST_new_TAGC_replication.csv")
audit = pd.read_csv(T / "ST_new_FI_item_audit.csv")
strength = pd.read_csv(T / "ST_new_instrument_strength.csv")

INSTR = ["Frailty", "GrimAge", "Hannum", "IEAA", "PhenoAge"]
construct = {
    "Frailty": "Deficit accumulation (49 items)",
    "GrimAge": "DNAm clock",
    "Hannum": "DNAm clock",
    "IEAA": "DNAm clock",
    "PhenoAge": "DNAm clock",
}
snps = {"Frailty": "66–71", "GrimAge": "5", "Hannum": "56", "IEAA": "133", "PhenoAge": "89"}
source = {"Frailty": "UKB 164,610 + TwinGene 10,616", "GrimAge": "~34,400 EUR",
          "Hannum": "~34,400 EUR", "IEAA": "~34,400 EUR", "PhenoAge": "~34,400 EUR"}


def set_cell_border(cell, **kwargs):
    tc = cell._tc
    tcPr = tc.get_or_add_tcPr()
    tcBorders = tcPr.first_child_found_in("w:tcBorders")
    if tcBorders is None:
        tcBorders = OxmlElement("w:tcBorders")
        tcPr.append(tcBorders)
    for edge in ("top", "left", "bottom", "right", "insideH", "insideV"):
        if edge in kwargs:
            tag = "w:{}".format(edge)
            element = tcBorders.find(qn(tag))
            if element is None:
                element = OxmlElement(tag)
                tcBorders.append(element)
            for key in ["sz", "val", "color", "space"]:
                if key in kwargs[edge]:
                    element.set(qn("w:{}".format(key)), str(kwargs[edge][key]))


def style_table(doc, header=True):
    table = doc.tables[-1]
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = True
    for i, row in enumerate(table.rows):
        for cell in row.cells:
            for p in cell.paragraphs:
                p.paragraph_format.space_before = Pt(1)
                p.paragraph_format.space_after = Pt(1)
                for r in p.runs:
                    r.font.name = "Arial"
                    r.font.size = Pt(7.5)
            set_cell_border(cell, top={"sz": 4, "val": "single", "color": "000000"} if i == 0 else {"sz": 0, "val": "nil"},
                            bottom={"sz": 4, "val": "single", "color": "000000"} if i == 0 or i == len(table.rows) - 1 else {"sz": 0, "val": "nil"},
                            left={"sz": 0, "val": "nil"}, right={"sz": 0, "val": "nil"})
            if i == 0:
                for p in cell.paragraphs:
                    for r in p.runs:
                        r.bold = True


def add_caption(doc, text):
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(0)
    p.paragraph_format.space_after = Pt(4)
    r = p.add_run(text)
    r.bold = True
    r.font.name = "Arial"
    r.font.size = Pt(8)


def new_doc():
    doc = Document()
    sec = doc.sections[0]
    sec.top_margin = Inches(0.5)
    sec.bottom_margin = Inches(0.5)
    sec.left_margin = Inches(0.5)
    sec.right_margin = Inches(0.5)
    return doc


# ---------------------------------------------------------------- Table 1
doc = new_doc()
add_caption(doc, "Table 1 | Ageing instruments and their properties.")
rows = [["Instrument", "Construct", "SNPs", "h² (SE)", "Mean χ²", "λGC", "Source"]]
for inst in INSTR:
    r = strength[strength.instrument == inst].iloc[0]
    rows.append([inst, construct[inst], snps[inst], f"{r.h2:.3f} ({r.h2_se:.3f})",
                 f"{r.mean_chi2:.2f}", f"{r.lambda_gc:.2f}", source[inst]])
table = doc.add_table(rows=len(rows), cols=len(rows[0]))
for i, row in enumerate(rows):
    for j, val in enumerate(row):
        table.cell(i, j).text = str(val)
style_table(doc)
p = doc.add_paragraph()
p.paragraph_format.space_before = Pt(3)
r = p.add_run("h², SNP heritability from canonical LDSC. The 49-item frailty index includes asthma (item 28) and hay fever/allergic rhinitis/eczema (item 33).")
r.font.name = "Arial"; r.font.size = Pt(6.5)
doc.save(OUT / "Table_1_instruments.docx")
(OUT / "Table_1_instruments.md").write_text(
    "# Table 1 | Ageing instruments and their properties.\n\n" +
    "\n".join(["| " + " | ".join(r) + " |" for r in rows[:1]] +
             ["|" + "---|" * len(rows[0])] +
             ["| " + " | ".join(r) + " |" for r in rows[1:]]) +
    "\n\nh², SNP heritability from canonical LDSC. The 49-item frailty index includes asthma (item 28) and hay fever/allergic rhinitis/eczema (item 33).\n",
    encoding="utf-8")
print("Table 1 saved")

# ---------------------------------------------------------------- Table 2
doc = new_doc()
add_caption(doc, "Table 2 | Genetic correlation with the three allergic outcomes.")
rows = [["Instrument", "Asthma", "Allergic rhinitis", "Atopic dermatitis"]]
for inst in INSTR:
    vals = []
    for oc in ["Asthma", "Allergic rhinitis", "Atopic dermatitis"]:
        rr = outcome[(outcome.instrument == inst) & (outcome.outcome == oc)].iloc[0]
        vals.append(f"{rr.rg:.3f} ({rr.rg_se:.3f})")
    rows.append([inst] + vals)
tr = tagc[tagc.model == "random"].iloc[0]
tf = tagc[tagc.model == "fixed"].iloc[0]
rows.append(["TAGC European (random)", f"{tr.rg:.3f} ({tr.se:.3f})", "—", "—"])
rows.append(["TAGC European (fixed)", f"{tf.rg:.3f} ({tf.se:.3f})", "—", "—"])
table = doc.add_table(rows=len(rows), cols=4)
for i, row in enumerate(rows):
    for j, val in enumerate(row):
        table.cell(i, j).text = str(val)
style_table(doc)
p = doc.add_paragraph()
p.paragraph_format.space_before = Pt(3)
r = p.add_run("Values are rg (SE). TAGC estimates are from the European-ancestry meta-analysis (N = 127,669); the same two outcome items are present in the exposure, so TAGC replicates the association, not the residual.")
r.font.name = "Arial"; r.font.size = Pt(6.5)
doc.save(OUT / "Table_2_genetic_correlations.docx")
(OUT / "Table_2_genetic_correlations.md").write_text(
    "# Table 2 | Genetic correlation with the three allergic outcomes.\n\n" +
    "\n".join(["| " + " | ".join(r) + " |" for r in rows[:1]] +
             ["|" + "---|" * len(rows[0])] +
             ["| " + " | ".join(r) + " |" for r in rows[1:]]) +
    "\n\nValues are rg (SE). TAGC estimates are from the European-ancestry meta-analysis (N = 127,669); the same two outcome items are present in the exposure, so TAGC replicates the association, not the residual.\n",
    encoding="utf-8")
print("Table 2 saved")

# ---------------------------------------------------------------- Table 3
doc = new_doc()
add_caption(doc, "Table 3 | Flagged items in the 49-item frailty index.")
rows = [["Item #", "Item", "Category", "Flag"]]
for _, r in audit.iterrows():
    rows.append([str(int(r["item_no"])), str(r["item"]), str(r["category"]), str(r["flag"])])
table = doc.add_table(rows=len(rows), cols=4)
for i, row in enumerate(rows):
    for j, val in enumerate(row):
        table.cell(i, j).text = str(val)
style_table(doc)
p = doc.add_paragraph()
p.paragraph_format.space_before = Pt(3)
r = p.add_run("2/49 items (4.1%) are the outcomes themselves; 9/49 (18.4%) are pain items. Full 49-item list in Williams et al. 2019.")
r.font.name = "Arial"; r.font.size = Pt(6.5)
doc.save(OUT / "Table_3_FI_item_audit.docx")
(OUT / "Table_3_FI_item_audit.md").write_text(
    "# Table 3 | Flagged items in the 49-item frailty index.\n\n" +
    "\n".join(["| " + " | ".join(r) + " |" for r in rows[:1]] +
             ["|" + "---|" * len(rows[0])] +
             ["| " + " | ".join(r) + " |" for r in rows[1:]]) +
    "\n\n2/49 items (4.1%) are the outcomes themselves; 9/49 (18.4%) are pain items. Full 49-item list in Williams et al. 2019.\n",
    encoding="utf-8")
print("Table 3 saved")
